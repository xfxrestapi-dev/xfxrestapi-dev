const JSON_HEADERS = {
  "content-type": "application/json; charset=UTF-8",
  "cache-control": "no-store",
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET,POST,OPTIONS",
  "access-control-allow-headers": "Content-Type, X-API-Key, Authorization"
};

const json = (data, status=200) =>
  new Response(JSON.stringify(data, null, 2), {
    status,
    headers: JSON_HEADERS
  });

async function sha256(value) {
  const bytes = new TextEncoder().encode(value);
  const hash = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(hash)].map(x => x.toString(16).padStart(2,"0")).join("");
}

function randomToken(bytes=32) {
  const a = new Uint8Array(bytes);
  crypto.getRandomValues(a);
  return [...a].map(x => x.toString(16).padStart(2,"0")).join("");
}

function validEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

async function getApiKey(request, url) {
  return request.headers.get("x-api-key")
    || url.searchParams.get("apikey")
    || url.searchParams.get("apiKey")
    || "";
}

async function requireApiKey(request, url, env) {
  if (!env.DB) return {ok:false, response:json({status:false,error:"D1_NOT_CONFIGURED"},500)};
  const key = await getApiKey(request,url);
  if (!key) return {ok:false, response:json({status:false,error:"API_KEY_REQUIRED"},401)};
  const hash = await sha256(key);
  const row = await env.DB.prepare(
    "SELECT id FROM api_keys WHERE key_hash=? AND revoked=0 LIMIT 1"
  ).bind(hash).first();
  if (!row) return {ok:false, response:json({status:false,error:"INVALID_API_KEY"},401)};
  return {ok:true};
}

/*
  EMAIL PROVIDER
  Configure these Worker secrets:
    EMAIL_API_URL   e.g. your transactional-email provider endpoint
    EMAIL_API_KEY
    EMAIL_FROM
  The provider must accept a POST JSON body:
    {to,from,subject,text,html}
*/
async function sendMail(env, to, token) {
  if (!env.EMAIL_API_URL || !env.EMAIL_API_KEY || !env.EMAIL_FROM) {
    return {ok:false, error:"EMAIL_PROVIDER_NOT_CONFIGURED"};
  }

  const verifyUrl = `${env.PUBLIC_BASE_URL || "https://xtzy.xyroxyz9.workers.dev"}/api/v1/alight-motion/verif?email=${encodeURIComponent(to)}&token=${encodeURIComponent(token)}`;

  const body = {
    to,
    from: env.EMAIL_FROM,
    subject: "Email Verification",
    text: `Verification link: ${verifyUrl}`,
    html: `<p>Verification link:</p><p><a href="${verifyUrl}">${verifyUrl}</a></p><p>Link expires in 15 minutes.</p>`
  };

  const r = await fetch(env.EMAIL_API_URL, {
    method:"POST",
    headers:{
      "content-type":"application/json",
      "authorization":`Bearer ${env.EMAIL_API_KEY}`
    },
    body:JSON.stringify(body)
  });

  return {ok:r.ok, status:r.status, response:(await r.text()).slice(0,500)};
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === "OPTIONS") {
      return new Response(null,{status:204,headers:JSON_HEADERS});
    }

    if (url.pathname === "/" && request.method === "GET") {
      return new Response(
`HeyyAarya API
GET  /api/health
POST /api/v1/apikey/generate
POST /api/v1/apikey/revoke
POST /api/v1/alight-motion/send
GET  /api/v1/alight-motion/verif`,
        {headers:{"content-type":"text/plain; charset=UTF-8","access-control-allow-origin":"*"}}
      );
    }

    if (url.pathname === "/api/health") {
      let db = false;
      try {
        if (env.DB) {
          await env.DB.prepare("SELECT 1 AS ok").first();
          db = true;
        }
      } catch {}
      return json({status:true,service:"HeyyAarya API",version:"v1",database:db});
    }

    if (url.pathname === "/api/v1/apikey/generate" && request.method === "POST") {
      if (!env.ADMIN_KEY) return json({status:false,error:"ADMIN_KEY_NOT_CONFIGURED"},500);

      const supplied = request.headers.get("x-admin-key") || "";
      if (supplied !== env.ADMIN_KEY) return json({status:false,error:"INVALID_ADMIN_KEY"},401);

      if (!env.DB) return json({status:false,error:"D1_NOT_CONFIGURED"},500);

      const raw = "heyyarya_" + randomToken(24);
      const hash = await sha256(raw);
      const prefix = raw.slice(0,17);

      await env.DB.prepare(
        "INSERT INTO api_keys(key_hash,key_prefix,created_at) VALUES(?,?,?)"
      ).bind(hash,prefix,Date.now()).run();

      return json({status:true,message:"API key generated",apikey:raw});
    }

    if (url.pathname === "/api/v1/apikey/revoke" && request.method === "POST") {
      if (!env.ADMIN_KEY) return json({status:false,error:"ADMIN_KEY_NOT_CONFIGURED"},500);
      const supplied = request.headers.get("x-admin-key") || "";
      if (supplied !== env.ADMIN_KEY) return json({status:false,error:"INVALID_ADMIN_KEY"},401);

      if (!env.DB) return json({status:false,error:"D1_NOT_CONFIGURED"},500);

      let body={};
      try { body=await request.json(); } catch {}
      if (!body.apikey) return json({status:false,error:"API_KEY_REQUIRED"},400);

      const hash = await sha256(body.apikey);
      const result = await env.DB.prepare(
        "UPDATE api_keys SET revoked=1 WHERE key_hash=?"
      ).bind(hash).run();

      return json({status:true,revoked:result.meta?.changes || 0});
    }

    if (url.pathname === "/api/v1/alight-motion/send") {
      if (!["GET","POST"].includes(request.method))
        return json({status:false,error:"METHOD_NOT_ALLOWED"},405);

      const auth = await requireApiKey(request,url,env);
      if (!auth.ok) return auth.response;

      let email = url.searchParams.get("email") || "";
      if (request.method === "POST") {
        try {
          const body=await request.json();
          email=body.email || email;
        } catch {}
      }

      email=email.trim().toLowerCase();
      if (!validEmail(email)) return json({status:false,error:"INVALID_EMAIL"},400);
      if (!env.DB) return json({status:false,error:"D1_NOT_CONFIGURED"},500);

      const token=randomToken(32);
      const tokenHash=await sha256(token);
      const expires=Date.now()+15*60*1000;

      await env.DB.prepare(
        "INSERT INTO verifications(email,token_hash,expires_at,used,created_at) VALUES(?,?,?,?,?)"
      ).bind(email,tokenHash,expires,0,Date.now()).run();

      const mail=await sendMail(env,email,token);

      if (!mail.ok) {
        return json({
          status:false,
          error:mail.error || "EMAIL_SEND_FAILED",
          provider_status:mail.status || null
        },502);
      }

      return json({
        status:true,
        message:"Verification email sent",
        email,
        expires_in:900
      });
    }

    if (url.pathname === "/api/v1/alight-motion/verif" && request.method === "GET") {
      const email=(url.searchParams.get("email")||"").trim().toLowerCase();
      const token=url.searchParams.get("token")||"";

      if (!validEmail(email)) return json({status:false,error:"INVALID_EMAIL"},400);
      if (!token) return json({status:false,error:"TOKEN_REQUIRED"},400);
      if (!env.DB) return json({status:false,error:"D1_NOT_CONFIGURED"},500);

      const hash=await sha256(token);
      const row=await env.DB.prepare(
        "SELECT id,expires_at,used FROM verifications WHERE email=? AND token_hash=? ORDER BY id DESC LIMIT 1"
      ).bind(email,hash).first();

      if (!row) return json({status:false,error:"INVALID_TOKEN"},400);
      if (row.used) return json({status:false,error:"TOKEN_ALREADY_USED"},400);
      if (Date.now()>row.expires_at) return json({status:false,error:"TOKEN_EXPIRED"},400);

      await env.DB.prepare("UPDATE verifications SET used=1 WHERE id=?").bind(row.id).run();

      return json({status:true,message:"Email verified",email});
    }

    return json({status:false,error:"NOT_FOUND",path:url.pathname},404);
  }
};
