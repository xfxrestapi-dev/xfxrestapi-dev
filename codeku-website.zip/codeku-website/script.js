// script.js
// Tempat menulis logika interaktif untuk website ini

document.addEventListener('DOMContentLoaded', () => {
  console.log('Codeku Website berhasil dimuat!');
});
