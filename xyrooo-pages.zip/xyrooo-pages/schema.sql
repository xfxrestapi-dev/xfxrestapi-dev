-- Skema database D1 untuk Xyrooo API Platform
-- Cara pakai (via Cloudflare Dashboard, TANPA command line):
-- 1. Buka Workers & Pages > D1 > database kamu > tab "Console"
-- 2. Copy-paste SELURUH isi file ini ke kotak query, lalu klik "Execute"

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT,          -- NULL kalau daftar lewat Google
  google_id TEXT UNIQUE,       -- NULL kalau daftar manual
  api_key TEXT UNIQUE NOT NULL,
  plan TEXT NOT NULL DEFAULT 'Free',
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS stats (
  key TEXT PRIMARY KEY,
  value INTEGER NOT NULL DEFAULT 0
);

INSERT OR IGNORE INTO stats (key, value) VALUES ('total_requests', 0);
