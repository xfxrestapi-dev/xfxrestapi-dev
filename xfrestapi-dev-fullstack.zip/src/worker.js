const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type,X-API-Key"
};

const HTML = `<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#07070a">
<title>HeyyAarya API</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#07070a;color:#f7f7fa;font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif}a{color:inherit}.wrap{max-width:1080px;margin:auto;padding:22px 16px 55px}header{border-bottom:1px solid #17171d}.nav{height:58px;display:flex;align-items:center;justify-content:space-between}.brand{font-weight:900;letter-spacing:-.04em;font-size:19px}.brand span{color:#777}.pill{font-size:11px;border:1px solid #25252c;border-radius:999px;padding:7px 10px;color:#aaa}.hero{text-align:center;padding:70px 0 48px}.ey{display:inline-block;border:1px solid #24242b;border-radius:999px;padding:8px 12px;font-size:10px;letter-spacing:.16em;color:#999;text-transform:uppercase}.hero h1{font-size:clamp(45px,9vw,88px);line-height:.92;letter-spacing:-.075em;margin:18px 0}.hero h1 span{color:#777}.hero p{max-width:680px;margin:auto;color:#92929c;line-height:1.75}.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}.card,.panel,.ep{background:#0d0d12;border:1px solid #22222a;border-radius:17px;padding:19px}.card small,.label{color:#777;font-size:10px;text-transform:uppercase;letter-spacing:.1em;font-weight:800}.card b{display:block;margin-top:8px}.ok{color:#65e6a0}.section{margin-top:58px}.section h2{font-size:27px;letter-spacing:-.04em;margin:6px 0 16px}.eps{display:grid;grid-template-columns:1fr 1fr;gap:12px}.method{display:inline-block;background:#18181f;color:#aaa;padding:6px 8px;border-radius:7px;font-size:10px;font-weight:900}.ep h3{margin:14px 0 7px}.muted{color:#92929c;font-size:13px;line-height:1.6}.url{margin-top:13px;background:#08080b;border:1px solid #27272f;border-radius:10px;padding:12px;font:11px/1.6 monospace;word-break:break-all;color:#d0d0d5}.tester{display:grid;grid-template-columns:1fr 1fr;gap:12px}.panel h3{margin:0 0 5px}.panel p{color:#777;font-size:12px}.label{display:block;margin:16px 0 7px}input{width:100%;padding:12px 13px;border-radius:10px;border:1px solid #292930;background:#08080b;color:#fff;outline:none}input:focus{border-color:#555}.btn{width:100%;margin-top:15px;padding:12px;border-radius:10px;border:1px solid #fff;background:#fff;color:#000;font-weight:800;cursor:pointer}.out{margin-top:12px;background:#08080b;border:1px solid #26262e;border-radius:10px;padding:12px;font:11px/1.6 monospace;white-space:pre-wrap;word-break:break-word;display:none}.docs{border:1px solid #22222a;border-radius:17px;overflow:hidden}.row{padding:18px;border-bottom:1px solid #22222a}.row:last-child{border:0}.row strong{font-size:13px}.row p{color:#888;font-size:12px;line-height:1.7;margin-bottom:0}footer{margin-top:60px;border-top:1px solid #17171d;padding-top:24px;color:#555;font-size:11px;text-align:center}@media(max-width:750px){.grid{grid-template-columns:1fr 1fr}.eps,.tester{grid-template-columns:1fr}}@media(max-width:430px){.grid{grid-template-columns:1fr 1fr}.hero{padding-top:50px}}
</style>
</head>
<body>
<div class="wrap">
<header><div class="nav"><div class="brand">HeyyAarya<span>.API</span></div><div class="pill">● ONLINE</div></div></header>
<div class="hero"><div class="ey">Developer Platform</div><h1>REST API<br><span>made simple.</span></h1><p>Cloudflare Worker + D1 dengan API key protection dan email verification. Satu dashboard untuk dokumentasi dan pengujian endpoint.</p></div>

<div class="grid">
<div class="card"><small>Status</small><b class="ok">Online</b></div>
<div class="card"><small>Version</small><b>v1</b></div>
<div class="card"><small>Database</small><b>D1</b></div>
<div class="card"><small>Auth</small><b>API Key</b></div>
</div>

<div class="section"><h2>Endpoints</h2>
<div class="eps">
<div class="ep"><span class="method">GET / POST</span><h3>Send Verification</h3><div class="muted">Membuat token verifikasi dan mengirim email.</div><div class="url">/api/v1/alight-motion/send</div></div>
<div class="ep"><span class="method">GET</span><h3>Verify Email</h3><div class="muted">Memvalidasi token sekali pakai yang masih berlaku.</div><div class="url">/api/v1/alight-motion/verif</div></div>
</div></div>

<div class="section"><h2>API Tester</h2>
<div class="tester">
<div class="panel"><h3>Send</h3><p>API key + email diperlukan.</p>
<label class="label">API Key</label><input id="key" type="password" placeholder="YOUR_API_KEY">
<label class="label">Email</label><input id="email" type="email" placeholder="user@gmail.com">
<button class="btn" onclick="sendReq()">Send Verification</button><pre id="sendOut" class="out"></pre></div>
<div class="panel"><h3>Verify</h3><p>Masukkan token dari email.</p>
<label class="label">Email</label><input id="vemail" type="email" placeholder="user@gmail.com">
<label class="label">Token</label><input id="token" placeholder="TOKEN">
<button class="btn" onclick="verifyReq()">Verify Email</button><pre id="verOut" class="out"></pre></div>
</div></div>

<div class="section"><h2>Quick Docs</h2><div class="docs">
<div class="row"><strong>Authentication</strong><p>Gunakan parameter <code>apikey</code> atau header <code>X-API-Key</code> pada endpoint send.</p></div>
<div class="row"><strong>Send</strong><p>https://heyyarya.dev/api/v1/alight-motion/send?apikey=YOUR_API_KEY&amp;email=user@gmail.com</p></div>
<div class="row"><strong>Verify</strong><p>https://heyyarya.dev/api/v1/alight-motion/verif?email=user@gmail.com&amp;token=TOKEN</p></div>
<div class="row"><strong>Security</strong><p>API key tidak disimpan di HTML. Untuk production, simpan sebagai Cloudflare Secret.</p></div>
</div></div>

<footer>© 2026 HeyyAarya API · Cloudflare Workers + D1</footer>
</div>
<script>
async function call(url,opts={}){try{const r=await fetch(url,opts);const t=await r.text();let d;try{d=JSON.parse(t)}catch{d={status:r.ok,response:t}};return d}catch(e){return{status:false,error:"FETCH_FAILED",message:e.message}}}
function show(id,d){const x=document.getElementById(id);x.style.display="block";x.textContent=JSON.stringify(d,null,2)}
async function sendReq(){const k=document.getElementById("key").value.trim(),e=document.getElementById("email").value.trim();if(!k||!e)return show("sendOut",{status:false,error:"API_KEY_AND_EMAIL_REQUIRED"});show("sendOut",{status:true,message:"Sending..."});show("sendOut",await call("/api/v1/alight-motion/send?apikey="+encodeURIComponent(k)+"&email="+encodeURIComponent(e)))}
async function verifyReq(){const e=document.getElementById("vemail").value.trim(),t=document.getElementById("token").value.trim();if(!e||!t)return show("verOut",{status:false,error:"EMAIL_AND_TOKEN_REQUIRED"});show("verOut",{status:true,message:"Verifying..."});show("verOut",await call("/api/v1/alight-motion/verif?email="+encodeURIComponent(e)+"&token="+encodeURIComponent(t)))}
</script>
</body></html>`;

function json(data, status=200) {
  return new Response(JSON.stringify(data, null, 2), {
    status,
    headers: {"content-type":"application/json; charset=UTF-8", ...CORS}
  });
}
function page() {
  return new Response(HTML, {headers: {"content-type":"text/html; charset=UTF-8", ...CORS}});
}
function validEmail(e){return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)}
async function sha256(v){const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(v));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("")}
function token(){const b=crypto.getRandomValues(new Uint8Array(32));return [...b].map(x=>x.toString(16).padStart(2,"0")).join("")}

async function auth(req,env,url){
  const k=req.headers.get("X-API-Key")||url.searchParams.get("apikey");
  if(!k)return false;
  if(env.API_KEY_HASH)return (await sha256(k))===env.API_KEY_HASH;
  return !!env.API_KEY && k===env.API_KEY;
}

async function sendMail(env,email,verifyUrl){
  if(!env.RESEND_API_KEY || !env.MAIL_FROM) return {sent:false,reason:"EMAIL_PROVIDER_NOT_CONFIGURED"};
  const r=await fetch("https://api.resend.com/emails",{
    method:"POST",
    headers:{"Authorization":`Bearer ${env.RESEND_API_KEY}`,"Content-Type":"application/json"},
    body:JSON.stringify({
      from:env.MAIL_FROM,to:[email],subject:"HeyyAarya API - Verify Email",
      html:`<div style="font-family:Arial;max-width:600px;margin:auto"><h2>HeyyAarya API</h2><p>Click the button below to verify your email.</p><p><a href="${verifyUrl}" style="display:inline-block;padding:12px 18px;background:#111;color:#fff;text-decoration:none;border-radius:8px">Verify Email</a></p><p>This link expires in 15 minutes.</p></div>`
    })
  });
  return r.ok ? {sent:true} : {sent:false,reason:"EMAIL_PROVIDER_ERROR",status:r.status};
}

async function sendHandler(req,env,url){
  if(!(await auth(req,env,url)))return json({status:false,error:"INVALID_API_KEY"},401);
  let email=url.searchParams.get("email");
  if(!email && req.method==="POST"){try{email=(await req.json()).email}catch{}}
  if(!email || !validEmail(email))return json({status:false,error:"INVALID_EMAIL"},400);
  email=email.trim().toLowerCase();

  const raw=token(), hash=await sha256(raw), id=crypto.randomUUID(), now=Date.now(), exp=now+15*60*1000;
  await env.DB.prepare("INSERT INTO verification_tokens (id,email,token_hash,expires_at,used,created_at) VALUES (?1,?2,?3,?4,0,?5)")
    .bind(id,email,hash,exp,now).run();

  const verifyUrl=`${url.origin}/api/v1/alight-motion/verif?email=${encodeURIComponent(email)}&token=${encodeURIComponent(raw)}`;
  const mail=await sendMail(env,email,verifyUrl);

  const result={status:true,message:mail.sent?"Verification email sent":"Token created but email provider is not configured",email,expires_in:"15 minutes"};
  if(!mail.sent && env.SHOW_DEV_VERIFY_URL==="true") result.dev_verify_url=verifyUrl;
  return json(result);
}

async function verifyHandler(env,url){
  const email=(url.searchParams.get("email")||"").trim().toLowerCase();
  const raw=url.searchParams.get("token")||"";
  if(!email||!validEmail(email))return json({status:false,error:"INVALID_EMAIL"},400);
  if(!raw)return json({status:false,error:"TOKEN_REQUIRED"},400);
  const hash=await sha256(raw);
  const row=await env.DB.prepare("SELECT id,expires_at,used FROM verification_tokens WHERE email=?1 AND token_hash=?2 ORDER BY created_at DESC LIMIT 1").bind(email,hash).first();
  if(!row)return json({status:false,error:"INVALID_TOKEN"},400);
  if(Number(row.used)===1)return json({status:false,error:"TOKEN_ALREADY_USED"},400);
  if(Number(row.expires_at)<Date.now())return json({status:false,error:"TOKEN_EXPIRED"},400);
  await env.DB.prepare("UPDATE verification_tokens SET used=1 WHERE id=?1").bind(row.id).run();
  await env.DB.prepare("INSERT INTO verified_emails (email,verified_at) VALUES (?1,?2) ON CONFLICT(email) DO UPDATE SET verified_at=excluded.verified_at").bind(email,Date.now()).run();
  return json({status:true,message:"Email verified successfully",email,verified_at:new Date().toISOString()});
}

export default {
  async fetch(req,env){
    const u=new URL(req.url);
    if(req.method==="OPTIONS")return new Response(null,{status:204,headers:CORS});
    if(u.pathname==="/"||u.pathname==="/docs")return page();
    try{
      if(u.pathname==="/api/v1/alight-motion/send" && ["GET","POST"].includes(req.method))return await sendHandler(req,env,u);
      if(u.pathname==="/api/v1/alight-motion/verif" && req.method==="GET")return await verifyHandler(env,u);
      if(u.pathname==="/api/health")return json({status:true,service:"heyyarya-api",version:"v1"});
      return json({status:false,error:"NOT_FOUND"},404);
    }catch(e){return json({status:false,error:"INTERNAL_ERROR",message:e.message},500)}
  }
};