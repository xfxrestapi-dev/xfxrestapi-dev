# Codeku Website

Struktur project website sederhana.

## Struktur File

```
codeku-website/
├── index.html   # Halaman utama
├── style.css    # Styling halaman
├── script.js    # Logika interaktif
└── README.md    # Dokumentasi project
```

## Cara Menjalankan

1. Ekstrak file zip ini.
2. Buka `index.html` langsung di browser, atau
3. Gunakan Live Server (VS Code extension) untuk preview otomatis.

## Kustomisasi

- Ubah konten di `index.html`
- Ubah tampilan di `style.css`
- Tambahkan interaksi di `script.js`
