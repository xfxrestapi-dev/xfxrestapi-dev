const DEFAULT_UPSTREAM = "https://am.yappi.my.id";
const USER_AGENT =
  "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36";

let cachedCookie = "";
let cachedAt = 0;
const COOKIE_TTL = 5 * 60 * 1000;

function corsHeaders(origin = "*") {
  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json; charset=utf-8"
  };
}

function json(data, status = 200, origin = "*") {
  return new Response(JSON.stringify(data, null, 2), {
    status,
    headers: corsHeaders(origin)
  });
}

function validEmail(email) {
  return typeof email === "string" &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

function cleanError(data, fallback) {
  return data?.error || data?.message || fallback;
}

async function upstreamRequest(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: {
      "User-Agent": USER_AGENT,
      "Accept": "*/*",
      ...(options.headers || {})
    }
  });

  const text = await response.text();
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    data = { ok: false, error: text || `Upstream HTTP ${response.status}` };
  }

  return { response, data };
}

async function getCookie(env, force = false) {
  const upstream = env.UPSTREAM_BASE || DEFAULT_UPSTREAM;
  const fresh = cachedCookie && Date.now() - cachedAt < COOKIE_TTL;

  if (!force && fresh) return cachedCookie;

  const { response, data } = await upstreamRequest(
    `${upstream}/api/cookie`
  );

  if (!response.ok || !data?.ok || !data?.cookie) {
    throw new Error(cleanError(data, "Gagal mendapatkan session cookie"));
  }

  cachedCookie = data.cookie;
  cachedAt = Date.now();
  return cachedCookie;
}

async function sendMagicLink(env, email, cookie) {
  const upstream = env.UPSTREAM_BASE || DEFAULT_UPSTREAM;

  const { response, data } = await upstreamRequest(
    `${upstream}/api/send`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Origin": upstream,
        "Referer": `${upstream}/`
      },
      body: JSON.stringify({ email, cookie })
    }
  );

  return { response, data };
}

async function verifyMagicLink(env, email, link, cookie) {
  const upstream = env.UPSTREAM_BASE || DEFAULT_UPSTREAM;

  const { response, data } = await upstreamRequest(
    `${upstream}/api/verify`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Origin": upstream,
        "Referer": `${upstream}/`
      },
      body: JSON.stringify({ email, link, cookie })
    }
  );

  return { response, data };
}

async function handleSend(request, env, origin) {
  let body;
  try {
    body = await request.json();
  } catch {
    return json({ ok: false, error: "Body harus JSON" }, 400, origin);
  }

  const email = String(body?.email || "").trim();

  if (!validEmail(email)) {
    return json({ ok: false, error: "Format email tidak valid" }, 400, origin);
  }

  try {
    let cookie = await getCookie(env);
    let result = await sendMagicLink(env, email, cookie);

    if (!result.data?.ok) {
      cookie = await getCookie(env, true);
      result = await sendMagicLink(env, email, cookie);
    }

    if (!result.data?.ok) {
      return json({
        ok: false,
        success: false,
        error: cleanError(result.data, "Gagal mengirim Magic Link")
      }, 400, origin);
    }

    return json({
      ok: true,
      success: true,
      email,
      message: result.data.message || "Magic Link berhasil dikirim"
    }, 200, origin);
  } catch (error) {
    return json({
      ok: false,
      success: false,
      error: error.message || "Send API Error"
    }, 502, origin);
  }
}

async function handleVerify(request, env, origin) {
  let body;
  try {
    body = await request.json();
  } catch {
    return json({ ok: false, error: "Body harus JSON" }, 400, origin);
  }

  const email = String(body?.email || "").trim();
  const link = String(body?.link || "").trim();

  if (!validEmail(email)) {
    return json({ ok: false, error: "Format email tidak valid" }, 400, origin);
  }

  if (!link || !/^https?:\/\//i.test(link)) {
    return json({ ok: false, error: "Magic Link tidak valid" }, 400, origin);
  }

  try {
    const cookie = await getCookie(env);
    const result = await verifyMagicLink(env, email, link, cookie);

    if (!result.data?.ok) {
      return json({
        ok: false,
        success: false,
        error: cleanError(result.data, "Verifikasi gagal")
      }, 400, origin);
    }

    const response = result.data || {};
    const user =
      response?.data?.user ||
      response?.user ||
      response?.data ||
      {};

    const createdAt = user?.createdAt ? Number(user.createdAt) : null;
    const lastLoginAt = user?.lastLoginAt ? Number(user.lastLoginAt) : null;

    return json({
      ok: true,
      success: true,
      email,
      user: {
        uid: user?.localId || "-",
        emailVerified: user?.emailVerified === true,
        createdAt: Number.isFinite(createdAt) ? new Date(createdAt).toISOString() : null,
        lastLoginAt: Number.isFinite(lastLoginAt) ? new Date(lastLoginAt).toISOString() : null
      },
      data: response
    }, 200, origin);
  } catch (error) {
    return json({
      ok: false,
      success: false,
      error: error.message || "Verify API Error"
    }, 502, origin);
  }
}

async function handle(request, env) {
  const origin = request.headers.get("Origin") || "*";
  const url = new URL(request.url);

  if (request.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: corsHeaders(origin)
    });
  }

  if (url.pathname === "/api/status" && request.method === "GET") {
    const started = Date.now();
    try {
      await getCookie(env);
      return json({
        ok: true,
        service: "AM Magic Link API",
        status: "online",
        upstream: env.UPSTREAM_BASE || DEFAULT_UPSTREAM,
        latency_ms: Date.now() - started,
        time: new Date().toISOString()
      }, 200, origin);
    } catch (error) {
      return json({
        ok: false,
        service: "AM Magic Link API",
        status: "degraded",
        error: error.message || "Upstream tidak dapat diakses",
        time: new Date().toISOString()
      }, 502, origin);
    }
  }

  if (url.pathname === "/api/send" && request.method === "POST") {
    return handleSend(request, env, origin);
  }

  if (url.pathname === "/api/verify" && request.method === "POST") {
    return handleVerify(request, env, origin);
  }

  if (url.pathname === "/api" && request.method === "GET") {
    return json({
      ok: true,
      name: "AM Magic Link API",
      version: "1.0.0",
      endpoints: {
        status: "GET /api/status",
        send: "POST /api/send",
        verify: "POST /api/verify"
      }
    }, 200, origin);
  }

  return json({ ok: false, error: "Endpoint not found" }, 404, origin);
}

export default {
  async fetch(request, env) {
    try {
      return await handle(request, env);
    } catch (error) {
      return json({ ok: false, error: "Internal Server Error" }, 500, "*");
    }
  }
};
