# Xtzy REST API backend starter — Python (FastAPI)
# Jalankan: uvicorn main:app --reload --port 8787

import os
import secrets
from datetime import datetime, timedelta

import httpx
import jwt
from fastapi import FastAPI, HTTPException, Header, Request
from fastapi.middleware.cors import CORSMiddleware
from google.oauth2 import id_token as google_id_token
from google.auth.transport import requests as google_requests
from pydantic import BaseModel

app = FastAPI(title="Xtzy REST API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

JWT_SECRET = os.getenv("JWT_SECRET", "change_me")
GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID", "")

# Ganti dengan database asli. Ini contoh in-memory saja.
USERS = {}


def make_api_key():
    return "xtzy_live_" + secrets.token_hex(16)


def issue_session(email: str, name: str):
    payload = {"sub": email, "name": name, "exp": datetime.utcnow() + timedelta(days=7)}
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")


class GoogleAuthBody(BaseModel):
    id_token: str


@app.get("/health")
def health():
    return {"status": "ok", "endpoints": 380}


@app.post("/api/auth/google")
def auth_google(body: GoogleAuthBody):
    try:
        payload = google_id_token.verify_oauth2_token(
            body.id_token, google_requests.Request(), GOOGLE_CLIENT_ID
        )
    except ValueError:
        raise HTTPException(status_code=401, detail="id_token tidak valid")

    email = payload["email"]
    user = USERS.get(email)
    if not user:
        user = {
            "email": email,
            "name": payload.get("name"),
            "avatar": payload.get("picture"),
            "plan": "free",
            "api_key": make_api_key(),
        }
        USERS[email] = user

    return {"session_token": issue_session(email, user["name"]), "user": user}


def require_api_key(x_api_key: str = Header(None)):
    if not x_api_key:
        raise HTTPException(status_code=401, detail="Header x-api-key wajib diisi")
    return x_api_key


@app.post("/api/v1/ai/chat")
async def ai_chat(request: Request, x_api_key: str = Header(None)):
    require_api_key(x_api_key)
    body = await request.json()
    prompt = body.get("prompt")
    if not prompt:
        raise HTTPException(status_code=400, detail="prompt wajib diisi")

    async with httpx.AsyncClient() as client:
        r = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "content-type": "application/json",
                "x-api-key": os.getenv("ANTHROPIC_API_KEY", ""),
                "anthropic-version": "2023-06-01",
            },
            json={
                "model": "claude-sonnet-4-6",
                "max_tokens": 1000,
                "messages": [{"role": "user", "content": prompt}],
            },
        )
        return r.json()


@app.get("/api/v1/tools/movie")
async def movie(title: str, x_api_key: str = Header(None)):
    require_api_key(x_api_key)
    async with httpx.AsyncClient() as client:
        r = await client.get(
            "https://www.omdbapi.com/",
            params={"apikey": os.getenv("OMDB_API_KEY", ""), "t": title},
        )
        return r.json()

# Tambahkan router lain (downloader, checkban, face-detection, dst) dengan pola yang sama:
# setiap grup fitur = satu blok endpoint, semua wajib require_api_key, dan panggil provider resmi.
