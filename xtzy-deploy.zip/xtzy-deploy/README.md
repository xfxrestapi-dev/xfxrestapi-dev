# Deploy xtzy.my.id lewat GitHub → Cloudflare (Pages + Worker)

Struktur folder:
```
xtzy-deploy/
├── pages/                  → frontend statis (index.html), di-deploy ke Cloudflare Pages
├── worker/                 → backend API (register/login/me), di-deploy ke Cloudflare Workers
└── .github/workflows/      → auto-deploy Worker via GitHub Actions
```

## 0. Prasyarat
- Domain `xtzy.my.id` sudah **Active** di Cloudflare (nameserver sudah diarahkan ke Cloudflare — kalau belum, selesaikan ini dulu sebelum lanjut).
- Sudah punya akun GitHub.

## 1. Push project ini ke GitHub
```bash
cd xtzy-deploy
git init
git add .
git commit -m "init xtzy deploy"
git branch -M main
git remote add origin https://github.com/USERNAME/xtzy-deploy.git
git push -u origin main
```

## 2. Deploy frontend (Cloudflare Pages) — via Git integration, tanpa Actions
1. Buka **dash.cloudflare.com** → **Workers & Pages** → **Create** → tab **Pages** → **Connect to Git**.
2. Pilih repo `xtzy-deploy` yang baru kamu push.
3. Isi build settings:
   - **Build command**: (kosongkan, tidak perlu build)
   - **Build output directory**: `pages`
4. Klik **Save and Deploy**.
5. Setelah deploy sukses → tab **Custom domains** → tambahkan `xtzy.my.id` (dan `www.xtzy.my.id` kalau perlu).

Setiap kali kamu push ke branch `main`, Cloudflare Pages otomatis re-deploy.

## 3. Deploy backend (Cloudflare Worker)
### a. Buat 2 KV namespace (sekali saja, lewat komputer/terminal kamu)
```bash
cd worker
npx wrangler login
npx wrangler kv namespace create USERS
npx wrangler kv namespace create SESSIONS
```
Setiap perintah di atas menghasilkan sebuah `id`. Tempel ke `worker/wrangler.toml`, ganti:
```
id = "REPLACE_WITH_USERS_KV_ID"
id = "REPLACE_WITH_SESSIONS_KV_ID"
```

### b. Deploy manual (opsional, sekali untuk tes)
```bash
npx wrangler deploy
```

### c. Auto-deploy via GitHub Actions (setiap push ke main)
1. Di Cloudflare dashboard → **My Profile** → **API Tokens** → **Create Token** → pakai template **Edit Cloudflare Workers** → **Continue to summary** → **Create Token**. Salin tokennya.
2. Di Cloudflare dashboard, catat juga **Account ID** (terlihat di sidebar kanan halaman overview domain).
3. Di GitHub repo kamu → **Settings** → **Secrets and variables** → **Actions** → tambahkan 2 secret:
   - `CLOUDFLARE_API_TOKEN` → token dari langkah 1
   - `CLOUDFLARE_ACCOUNT_ID` → account ID dari langkah 2
4. Commit & push perubahan apa pun di folder `worker/` → GitHub Actions (`.github/workflows/deploy-worker.yml`) otomatis jalan dan deploy Worker.

Worker ini sudah diatur (lewat `routes` di `wrangler.toml`) untuk menangani semua request ke `xtzy.my.id/api/*` — jadi frontend di Pages dan backend di Worker berbagi domain yang sama, tanpa perlu subdomain terpisah dan CORS jadi lebih simpel.

## 4. Setup Login Google (OAuth)
Worker sudah punya endpoint `/api/auth/google` dan `/api/auth/google/callback`. Yang perlu kamu siapkan hanya kredensial dari Google:

1. Buka **console.cloud.google.com** → buat project baru (atau pakai yang sudah ada).
2. Menu **APIs & Services** → **OAuth consent screen** → pilih **External** → isi nama app, email → simpan.
3. Menu **APIs & Services** → **Credentials** → **Create Credentials** → **OAuth client ID** → tipe **Web application**.
4. Isi:
   - **Authorized JavaScript origins**: `https://xtzy.my.id`
   - **Authorized redirect URIs**: `https://xtzy.my.id/api/auth/google/callback`
5. Klik **Create** → salin **Client ID** dan **Client Secret** yang muncul.
6. Set sebagai secret di Worker (dari folder `worker/`, sekali saja lewat terminal):
   ```bash
   npx wrangler secret put GOOGLE_CLIENT_ID
   # paste Client ID kamu saat diminta

   npx wrangler secret put GOOGLE_CLIENT_SECRET
   # paste Client Secret kamu saat diminta
   ```
7. Deploy ulang Worker (`npx wrangler deploy`, atau push ke GitHub kalau pakai Actions).

Setelah ini, tombol "Lanjutkan dengan Google" / "Daftar dengan Google" di halaman kamu akan: redirect ke Google → user login/setuju → Google balik ke Worker → Worker buat/ambil akun user tersebut → redirect balik ke halaman kamu dengan `?token=...` (sudah otomatis ditangkap oleh `captureOAuthToken()` di frontend).

## 5. Cek hasilnya
- Buka `https://xtzy.my.id` → indikator "Terhubung ke xtzy.my.id" di halaman harus berubah jadi hijau/OK.
- Coba **Daftar** akun baru lewat form → kalau berhasil, Worker + KV sudah nyambung dengan benar.
- Coba tombol **Google** → kalau redirect balik dengan dashboard terisi, OAuth sudah jalan.

## Catatan
- Password akun biasa di-hash pakai PBKDF2 (Web Crypto API), bukan disimpan polos.
- Akun yang dibuat lewat Google tidak punya password lokal (`hash: null`) — login akun itu hanya bisa lewat tombol Google.
- Kalau redirect Google gagal dengan error `redirect_uri_mismatch`, cek lagi Authorized redirect URI di langkah 4 — harus **persis sama**, termasuk `https://` dan tanpa trailing slash.
