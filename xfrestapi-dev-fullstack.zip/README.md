# xfrestapi-dev — HeyyAarya API

Full-stack Cloudflare Worker + D1 + email verification.

## Important

The Worker name is intentionally `xfrestapi-dev` to match the Cloudflare project shown in the dashboard. Cloudflare Workers Builds requires the dashboard Worker name and Wrangler `name` to match.

## GitHub / Cloudflare Workers Builds

Repository root must contain:

- `wrangler.toml`
- `package.json`
- `schema.sql`
- `src/worker.js`

Build command: leave empty.

Deploy command:

```bash
npx wrangler deploy
```

Root directory: `/`

## D1

Create:

```bash
npx wrangler d1 create xfrestapi-db
```

Copy the returned database ID into `wrangler.toml`, replacing:

```toml
database_id = "REPLACE_WITH_YOUR_D1_DATABASE_ID"
```

Initialize:

```bash
npx wrangler d1 execute xfrestapi-db --remote --file=schema.sql
```

## Secrets

Set an API key:

```bash
npx wrangler secret put API_KEY
```

Set email provider:

```bash
npx wrangler secret put RESEND_API_KEY
```

The sender domain/address must be configured with your email provider.

Optional production-hardening: instead of API_KEY, store a SHA-256 hash as `API_KEY_HASH`. If `API_KEY_HASH` exists, it takes precedence.

## Deploy

```bash
npm install
npx wrangler deploy
```

## URLs

Dashboard:

```text
https://heyyarya.dev/
```

Health:

```text
https://heyyarya.dev/api/health
```

Send:

```text
https://heyyarya.dev/api/v1/alight-motion/send?apikey=YOUR_API_KEY&email=user@gmail.com
```

Verify:

```text
https://heyyarya.dev/api/v1/alight-motion/verif?email=user@gmail.com&token=TOKEN
```

This project implements email verification for an API you control. It does not bypass or unlock a third-party application's paid features.
