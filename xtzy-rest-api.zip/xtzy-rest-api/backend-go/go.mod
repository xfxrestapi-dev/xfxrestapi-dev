module xtzy-rest-api-backend

go 1.21

require (
	github.com/golang-jwt/jwt/v5 v5.2.1
	google.golang.org/api v0.181.0
)
