# Xtzy REST API — Starter Project

Landing page premium + dashboard + backend starter (Node.js/Python/PHP/Go) untuk platform REST API.

## Struktur folder

```
frontend/           -> landing page, login, dashboard (statis, siap deploy ke Cloudflare Pages)
backend-node/        -> starter Express (paling lengkap, pakai ini sebagai referensi utama)
backend-python/       -> starter FastAPI
backend-php/         -> starter PHP
backend-go/          -> starter Go
.github/workflows/    -> auto-deploy frontend ke Cloudflare Pages lewat GitHub Actions
```

Kenapa cuma beberapa endpoint contoh, bukan 380? Karena tiap endpoint idealnya memanggil
provider resmi yang berbeda (AI, media, dsb) dan butuh API key masing-masing. Struktur di atas
dibuat supaya kamu tinggal menambah file/handler baru dengan pola yang sama untuk setiap
endpoint baru — lihat komentar "Tambahkan endpoint lain di sini" di tiap file.

Satu fitur yang sengaja **tidak disertakan**: generator akun premium (mis. "Netflix generator").
Itu biasanya berarti menghasilkan kredensial akun orang lain secara ilegal, jadi tidak saya buatkan.
Kalau maksudnya integrasi resmi (mis. mengecek status langganan lewat akun milik user sendiri),
itu bisa dibangun dengan pola yang sama seperti endpoint lain di sini.

---

## 1. Setup Google Login (real OAuth)

1. Buka [Google Cloud Console](https://console.cloud.google.com/) → buat project baru.
2. Masuk ke **APIs & Services → Credentials → Create Credentials → OAuth Client ID**.
3. Pilih tipe **Web application**.
4. Isi **Authorized JavaScript origins**, contoh:
   - `http://localhost:5500` (untuk testing lokal)
   - `https://xtzy-rest-api.pages.dev` (domain Cloudflare Pages kamu nanti)
5. Copy **Client ID** yang muncul.
6. Tempel Client ID itu ke:
   - `frontend/login.html` → variabel `GOOGLE_CLIENT_ID`
   - `backend-node/.env` (atau `.env` backend lain) → `GOOGLE_CLIENT_ID`

Tanpa langkah ini, tombol Google Sign-In akan tampil tapi menampilkan pesan error saat diklik —
itu memang disengaja supaya tidak ada yang mengira OAuth-nya jalan padahal belum dikonfigurasi.

---

## 2. Jalankan backend lokal

Pilih salah satu (contoh Node.js):

```bash
cd backend-node
cp .env.example .env
# isi .env: JWT_SECRET, GOOGLE_CLIENT_ID, dan API key provider yang mau dipakai
npm install
npm run dev
```

Backend akan jalan di `http://localhost:8787`. Buka `frontend/login.html` dengan Live Server
(atau `python -m http.server` di folder frontend), lalu ubah `API_BASE` di `login.html` dan
`dashboard.html` ke `http://localhost:8787`.

Python:
```bash
cd backend-python
cp .env.example .env
pip install -r requirements.txt
uvicorn main:app --reload --port 8787
```

PHP:
```bash
cd backend-php
cp .env.example .env
composer install
php -S localhost:8787
```

Go:
```bash
cd backend-go
cp .env.example .env
go mod tidy
go run main.go
```

---

## 3. Push ke GitHub

```bash
cd xtzy-rest-api-project
git init
git add .
git commit -m "Initial commit: Xtzy REST API starter"
git branch -M main
git remote add origin https://github.com/USERNAME/xtzy-rest-api.git
git push -u origin main
```

---

## 4. Deploy frontend ke Cloudflare Pages

Error `Could not detect a directory containing static files` muncul karena Cloudflare tidak
nemu folder yang berisi HTML di lokasi yang dia cek. File `wrangler.toml` di root project ini
sudah memberitahu Cloudflare bahwa folder outputnya adalah `frontend` — tapi kalau project
Pages kamu sudah kadung dibuat dengan setting salah, ikuti langkah **perbaikan** di bawah.

**Kalau bikin project baru dari awal:**
1. Buka [dash.cloudflare.com](https://dash.cloudflare.com) → **Workers & Pages → Create → Pages → Connect to Git**.
2. Pilih repo `xtzy-rest-api` yang baru di-push.
3. Di halaman "Set up builds and deployments":
   - **Framework preset**: pilih `None`
   - **Build command**: kosongkan total (jangan diisi apa pun)
   - **Build output directory**: ketik `frontend` — pastikan sama persis dengan nama folder di GitHub, tanpa `/` di depan
4. Klik **Save and Deploy**.

**Kalau project Pages sudah ada dan masih error (paling sering ini penyebabnya):**
1. Cek dulu di GitHub: buka repo kamu di browser, pastikan ada folder bernama `frontend` yang isinya `index.html`, `login.html`, `dashboard.html` langsung di dalamnya (bukan ke-nested lagi, misal `frontend/frontend/index.html`).
2. Masuk ke project Pages → **Settings → Builds & deployments → Build configurations**.
3. Klik **Edit** pada baris "Build output directory", ganti isinya jadi `frontend`, simpan.
4. Balik ke tab **Deployments** → klik titik tiga pada deployment terakhir → **Retry deployment**.
5. Kalau masih gagal juga, hapus project Pages itu dan buat ulang dari langkah "bikin project baru" di atas — kadang setting lama nyangkut di cache Cloudflare.

**Cara paling anti-gagal (pakai CLI, skip dashboard sama sekali):**
```bash
npm install -g wrangler
wrangler login
cd xtzy-rest-api-project
wrangler pages deploy frontend --project-name=xtzy-rest-api
```
Karena kamu langsung menunjuk folder `frontend` di command-nya, tidak ada ruang buat Cloudflare salah tebak.

**Cara otomatis lewat GitHub Actions** (file `.github/workflows/deploy.yml` sudah disiapkan):
1. Ambil **Account ID** dari dashboard Cloudflare (kanan bawah halaman overview).
2. Buat **API Token** di [Cloudflare API Tokens](https://dash.cloudflare.com/profile/api-tokens) dengan permission **Cloudflare Pages: Edit**.
3. Di repo GitHub, buka **Settings → Secrets and variables → Actions**, tambahkan:
   - `CLOUDFLARE_API_TOKEN`
   - `CLOUDFLARE_ACCOUNT_ID`
4. Setiap push ke branch `main` yang mengubah folder `frontend/` akan otomatis deploy.

---

## 5. Deploy backend

Cloudflare Pages **tidak menjalankan backend Node/Python/PHP/Go** secara langsung — Pages hanya
untuk file statis, dan Cloudflare Workers hanya mendukung JavaScript/TypeScript (atau WASM).
Untuk backend Node/Python/PHP/Go, pakai salah satu (semuanya punya free tier):

- **Render** (render.com) — paling mudah, tinggal connect repo, deteksi otomatis.
- **Railway** (railway.app) — mirip Render, cocok untuk Node/Python/Go.
- **Fly.io** — cocok kalau mau kontrol lebih (Docker-based), termasuk PHP.
- **VPS sendiri** (mis. lewat Cloudflare Tunnel kalau mau tetap pakai domain Cloudflare di depan).

Setelah backend live, update `API_BASE` di `frontend/login.html` dan `frontend/dashboard.html`
ke URL backend tersebut, lalu commit + push supaya frontend ikut ter-update.

---

## 6. Menambah endpoint baru (menuju 380+)

Setiap kategori (`ai`, `downloader`, `tools`, dst) adalah satu file router. Untuk menambah
endpoint baru:
1. Tambahkan fungsi handler baru di file router yang sesuai (atau bikin file router baru untuk
   kategori baru).
2. Pastikan tiap endpoint tetap lewat pengecekan `x-api-key`.
3. Idealnya setiap endpoint memanggil API resmi providernya (Anthropic, OMDb, Steam Web API,
   WhatsApp Cloud API, dll) — bukan scraping yang melanggar ketentuan layanan mereka.
4. Update dokumentasi endpoint di dashboard (`frontend/dashboard.html`) supaya user tahu
   endpoint baru itu ada.
