<?php
// Xtzy REST API backend starter — PHP
// Jalankan lokal: php -S localhost:8787
// Butuh: composer require google/apiclient firebase/php-jwt

require __DIR__ . '/vendor/autoload.php';
use Firebase\JWT\JWT;

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, x-api-key');

$dotenv = parse_ini_file(__DIR__ . '/.env');
$JWT_SECRET = $dotenv['JWT_SECRET'] ?? 'change_me';
$GOOGLE_CLIENT_ID = $dotenv['GOOGLE_CLIENT_ID'] ?? '';

$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

function require_api_key() {
    $key = $_SERVER['HTTP_X_API_KEY'] ?? null;
    if (!$key) {
        http_response_code(401);
        echo json_encode(['error' => 'Header x-api-key wajib diisi']);
        exit;
    }
}

if ($path === '/health') {
    echo json_encode(['status' => 'ok', 'endpoints' => 380]);
    exit;
}

if ($path === '/api/auth/google' && $method === 'POST') {
    $body = json_decode(file_get_contents('php://input'), true);
    $idToken = $body['id_token'] ?? null;
    if (!$idToken) {
        http_response_code(400);
        echo json_encode(['message' => 'id_token wajib diisi']);
        exit;
    }

    $client = new Google_Client(['client_id' => $GOOGLE_CLIENT_ID]);
    $payload = $client->verifyIdToken($idToken);
    if (!$payload) {
        http_response_code(401);
        echo json_encode(['message' => 'id_token tidak valid']);
        exit;
    }

    $email = $payload['email'];
    // TODO: simpan/ambil user dari database asli (MySQL/Postgres), bukan variabel sementara.
    $user = [
        'email' => $email,
        'name' => $payload['name'],
        'avatar' => $payload['picture'],
        'plan' => 'free',
        'api_key' => 'xtzy_live_' . bin2hex(random_bytes(16)),
    ];

    $sessionToken = JWT::encode(
        ['sub' => $email, 'name' => $payload['name'], 'exp' => time() + 604800],
        $JWT_SECRET,
        'HS256'
    );

    echo json_encode(['session_token' => $sessionToken, 'user' => $user]);
    exit;
}

if ($path === '/api/v1/tools/movie' && $method === 'GET') {
    require_api_key();
    $title = $_GET['title'] ?? null;
    if (!$title) {
        http_response_code(400);
        echo json_encode(['error' => 'title wajib diisi']);
        exit;
    }
    $apiKey = $dotenv['OMDB_API_KEY'] ?? '';
    $resp = file_get_contents('https://www.omdbapi.com/?apikey=' . $apiKey . '&t=' . urlencode($title));
    echo $resp;
    exit;
}

// Tambahkan endpoint lain di sini dengan pola yang sama:
// cek $path dan $method, panggil require_api_key(), lalu proxy ke provider resmi.

http_response_code(404);
echo json_encode(['error' => 'Endpoint tidak ditemukan', 'path' => $path]);
