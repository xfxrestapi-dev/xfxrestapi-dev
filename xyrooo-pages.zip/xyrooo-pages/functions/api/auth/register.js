import { json, CORS_HEADERS, hashPassword, genApiKey, makeSessionToken } from '../../_lib/helpers.js';

export async function onRequestPost({ request, env }) {
  const body = await request.json().catch(() => ({}));
  const { name, email, password } = body;
  if (!name || !email || !password) return json({ message: 'Lengkapi semua kolom.' }, 400);

  const existing = await env.DB.prepare('SELECT id FROM users WHERE email = ?').bind(email).first();
  if (existing) return json({ message: 'Email sudah terdaftar.' }, 409);

  const id = crypto.randomUUID();
  const passwordHash = await hashPassword(password);
  const apiKey = genApiKey();
  const now = Math.floor(Date.now() / 1000);

  await env.DB.prepare(
    'INSERT INTO users (id, name, email, password_hash, api_key, plan, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
  ).bind(id, name, email, passwordHash, apiKey, 'Free', now).run();

  const token = await makeSessionToken(id, env.JWT_SECRET);
  return json({ token, api_key: apiKey });
}

export async function onRequestOptions() {
  return new Response(null, { headers: CORS_HEADERS });
}
