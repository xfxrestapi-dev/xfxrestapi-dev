import { json, CORS_HEADERS, verifyPassword, makeSessionToken } from '../../_lib/helpers.js';

export async function onRequestPost({ request, env }) {
  const body = await request.json().catch(() => ({}));
  const { email, password } = body;
  if (!email || !password) return json({ message: 'Lengkapi email dan password.' }, 400);

  const user = await env.DB.prepare('SELECT * FROM users WHERE email = ?').bind(email).first();
  if (!user || !user.password_hash) return json({ message: 'Email atau password salah.' }, 401);

  const ok = await verifyPassword(password, user.password_hash);
  if (!ok) return json({ message: 'Email atau password salah.' }, 401);

  const token = await makeSessionToken(user.id, env.JWT_SECRET);
  return json({ token, api_key: user.api_key });
}

export async function onRequestOptions() {
  return new Response(null, { headers: CORS_HEADERS });
}
