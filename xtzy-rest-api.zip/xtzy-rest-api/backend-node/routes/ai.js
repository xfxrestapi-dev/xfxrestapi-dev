const express = require('express');
const router = express.Router();

// Middleware sederhana untuk cek API key (ganti dengan lookup ke database)
function requireApiKey(req, res, next) {
  const key = req.header('x-api-key');
  if (!key) return res.status(401).json({ error: 'Header x-api-key wajib diisi' });
  next();
}
router.use(requireApiKey);

// POST /api/v1/ai/chat — contoh proxy ke Anthropic API (isi ANTHROPIC_API_KEY di .env)
router.post('/chat', async (req, res) => {
  const { prompt } = req.body;
  if (!prompt) return res.status(400).json({ error: 'prompt wajib diisi' });

  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1000,
        messages: [{ role: 'user', content: prompt }]
      })
    });
    const data = await r.json();
    res.json({ result: data.content });
  } catch (err) {
    res.status(502).json({ error: 'Gagal menghubungi provider AI' });
  }
});

// POST /api/v1/ai/suno — generate musik dari prompt
// Catatan: Suno tidak punya API resmi publik. Hubungkan ke provider musik AI
// yang punya lisensi resmi (mis. lewat partner API), isi endpoint di bawah.
router.post('/suno', async (req, res) => {
  const { lyrics, genre } = req.body;
  if (!lyrics) return res.status(400).json({ error: 'lyrics wajib diisi' });
  // TODO: panggil provider musik AI resmi di sini
  res.status(501).json({ error: 'Belum dikonfigurasi. Isi kredensial provider musik AI di .env' });
});

// POST /api/v1/ai/image-to-video
router.post('/image-to-video', async (req, res) => {
  const { image_url } = req.body;
  if (!image_url) return res.status(400).json({ error: 'image_url wajib diisi' });
  // TODO: panggil provider image-to-video pilihanmu (mis. Runway, Kling, dsb via API resmi mereka)
  res.status(501).json({ error: 'Belum dikonfigurasi. Isi kredensial provider di .env' });
});

// POST /api/v1/ai/face-detection
router.post('/face-detection', async (req, res) => {
  const { image_url } = req.body;
  if (!image_url) return res.status(400).json({ error: 'image_url wajib diisi' });
  // TODO: integrasikan dengan provider vision (mis. Google Vision API, AWS Rekognition)
  res.status(501).json({ error: 'Belum dikonfigurasi. Isi kredensial provider di .env' });
});

module.exports = router;
