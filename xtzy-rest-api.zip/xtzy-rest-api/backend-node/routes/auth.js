const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { OAuth2Client } = require('google-auth-library');

const router = express.Router();
const googleClient = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

// Ganti dengan database asli (Postgres/MySQL/SQLite). Ini contoh in-memory saja.
const users = new Map(); // key: email

function makeApiKey() {
  return 'xtzy_live_' + require('crypto').randomBytes(16).toString('hex');
}

function issueSession(user) {
  return jwt.sign(
    { sub: user.email, name: user.name },
    process.env.JWT_SECRET,
    { expiresIn: '7d' }
  );
}

// POST /api/auth/google — verifikasi id_token dari Google Identity Services
router.post('/google', async (req, res) => {
  const { id_token } = req.body;
  if (!id_token) return res.status(400).json({ message: 'id_token wajib diisi' });

  try {
    const ticket = await googleClient.verifyIdToken({
      idToken: id_token,
      audience: process.env.GOOGLE_CLIENT_ID
    });
    const payload = ticket.getPayload();
    const email = payload.email;

    let user = users.get(email);
    if (!user) {
      user = {
        email,
        name: payload.name,
        avatar: payload.picture,
        plan: 'free',
        api_key: makeApiKey()
      };
      users.set(email, user);
    }

    const session_token = issueSession(user);
    res.json({ session_token, user });
  } catch (err) {
    res.status(401).json({ message: 'id_token tidak valid' });
  }
});

// POST /api/auth/register — email/password (opsional, di luar Google)
router.post('/register', async (req, res) => {
  const { email, password, name } = req.body;
  if (!email || !password) return res.status(400).json({ message: 'Email dan kata sandi wajib diisi' });
  if (users.has(email)) return res.status(409).json({ message: 'Email sudah terdaftar' });

  const password_hash = await bcrypt.hash(password, 10);
  const user = { email, name: name || email.split('@')[0], password_hash, plan: 'free', api_key: makeApiKey() };
  users.set(email, user);

  const session_token = issueSession(user);
  res.json({ session_token, user: { email: user.email, name: user.name, plan: user.plan } });
});

// POST /api/auth/login — email/password
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = users.get(email);
  if (!user || !user.password_hash) return res.status(401).json({ message: 'Email atau kata sandi salah' });

  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) return res.status(401).json({ message: 'Email atau kata sandi salah' });

  const session_token = issueSession(user);
  res.json({ session_token, user: { email: user.email, name: user.name, plan: user.plan } });
});

module.exports = router;
