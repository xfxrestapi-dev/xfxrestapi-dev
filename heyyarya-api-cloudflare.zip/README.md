# HeyyAarya API

Cloudflare Workers + D1 REST API platform.

## Endpoints

GET/POST `/api/v1/alight-motion/send`

GET `/api/v1/alight-motion/verif`

## 1. Install

```bash
npm install
npx wrangler login
```

## 2. Create D1

```bash
npx wrangler d1 create heyyarya-api-db
```

Copy the returned `database_id` into `wrangler.toml`.

Then:

```bash
npx wrangler d1 execute heyyarya-api-db --remote --file=schema.sql
```

## 3. Secrets

Do not put the real API key in GitHub.

```bash
npx wrangler secret put API_KEY
npx wrangler secret put RESEND_API_KEY
```

For the sender address, set `MAIL_FROM` in `wrangler.toml`.

For production, you can instead use `API_KEY_HASH`. Generate a SHA-256 hash of your API key and:

```bash
npx wrangler secret put API_KEY_HASH
```

If `API_KEY_HASH` exists, the Worker checks the hash and ignores `API_KEY`.

## 4. Deploy

```bash
npm run deploy
```

## 5. Custom domain

The included Wrangler configuration uses `heyyarya.dev` as a Custom Domain.

Your domain must be active in the same Cloudflare account/zone. Cloudflare will handle the DNS record and certificate for a Custom Domain.

## 6. Test

```bash
curl "https://heyyarya.dev/api/v1/alight-motion/send?apikey=YOUR_API_KEY&email=your@gmail.com"
```

Then use the verification link received by email:

```text
https://heyyarya.dev/api/v1/alight-motion/verif?email=your@gmail.com&token=...
```

## Email provider

Cloudflare Workers does not provide arbitrary SMTP connections. This project uses the Resend HTTP API so the Worker can send email from the edge.

Configure and verify your sending domain in your email provider before production use.
