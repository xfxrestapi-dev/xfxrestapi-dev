const express = require('express');
const router = express.Router();

function requireApiKey(req, res, next) {
  const key = req.header('x-api-key');
  if (!key) return res.status(401).json({ error: 'Header x-api-key wajib diisi' });
  next();
}
router.use(requireApiKey);

// GET /api/v1/tools/checkban?service=steam&id=...
// Contoh: cek status akun lewat API resmi/publik milik layanan tsb (bukan tool cheat/bypass).
router.get('/checkban', async (req, res) => {
  const { service, id } = req.query;
  if (!service || !id) return res.status(400).json({ error: 'service dan id wajib diisi' });

  if (service === 'steam') {
    // Steam Web API resmi: GetPlayerBans. Isi STEAM_API_KEY di .env (gratis dari Steam).
    try {
      const r = await fetch(`https://api.steampowered.com/ISteamUser/GetPlayerBans/v1/?key=${process.env.STEAM_API_KEY}&steamids=${id}`);
      const data = await r.json();
      res.json(data.players?.[0] || { error: 'ID tidak ditemukan' });
    } catch (err) {
      res.status(502).json({ error: 'Gagal menghubungi Steam API' });
    }
    return;
  }

  res.status(400).json({ error: `Service '${service}' belum didukung. Tambahkan integrasi API resmi layanan tsb.` });
});

// GET /api/v1/tools/movie?title=...
// Pakai OMDb API (butuh API key gratis dari omdbapi.com)
router.get('/movie', async (req, res) => {
  const { title } = req.query;
  if (!title) return res.status(400).json({ error: 'title wajib diisi' });
  try {
    const r = await fetch(`https://www.omdbapi.com/?apikey=${process.env.OMDB_API_KEY}&t=${encodeURIComponent(title)}`);
    const data = await r.json();
    res.json(data);
  } catch (err) {
    res.status(502).json({ error: 'Gagal mengambil data film' });
  }
});

// GET /api/v1/tools/search?q=...
// Pakai Google Custom Search JSON API resmi (butuh API key + Search Engine ID)
router.get('/search', async (req, res) => {
  const { q } = req.query;
  if (!q) return res.status(400).json({ error: 'q wajib diisi' });
  try {
    const url = `https://www.googleapis.com/customsearch/v1?key=${process.env.GOOGLE_SEARCH_API_KEY}&cx=${process.env.GOOGLE_SEARCH_CX}&q=${encodeURIComponent(q)}`;
    const r = await fetch(url);
    const data = await r.json();
    res.json(data.items || []);
  } catch (err) {
    res.status(502).json({ error: 'Gagal melakukan pencarian' });
  }
});

// POST /api/v1/tools/wa-reaction
// Kirim reaksi via WhatsApp Business Cloud API resmi (butuh akses resmi Meta).
router.post('/wa-reaction', async (req, res) => {
  const { message_id, to, emoji, phone_number_id } = req.body;
  if (!message_id || !to || !emoji) return res.status(400).json({ error: 'message_id, to, dan emoji wajib diisi' });

  try {
    const r = await fetch(`https://graph.facebook.com/v19.0/${phone_number_id}/messages`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.WHATSAPP_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        to,
        type: 'reaction',
        reaction: { message_id, emoji }
      })
    });
    const data = await r.json();
    res.json(data);
  } catch (err) {
    res.status(502).json({ error: 'Gagal mengirim reaksi WhatsApp' });
  }
});

module.exports = router;
