CREATE TABLE IF NOT EXISTS verification_tokens (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL,
  token_hash TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  used INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_verification_email
ON verification_tokens(email);

CREATE TABLE IF NOT EXISTS verified_emails (
  email TEXT PRIMARY KEY,
  verified_at INTEGER NOT NULL
);