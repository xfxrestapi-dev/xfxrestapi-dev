import { json, CORS_HEADERS } from '../_lib/helpers.js';

export async function onRequestGet() {
  return json({ status: 'ok', message: 'Xyrooo API aktif (Cloudflare Pages Functions)' });
}

export async function onRequestOptions() {
  return new Response(null, { headers: CORS_HEADERS });
}
