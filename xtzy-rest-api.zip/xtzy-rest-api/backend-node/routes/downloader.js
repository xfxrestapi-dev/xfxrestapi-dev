const express = require('express');
const router = express.Router();

function requireApiKey(req, res, next) {
  const key = req.header('x-api-key');
  if (!key) return res.status(401).json({ error: 'Header x-api-key wajib diisi' });
  next();
}
router.use(requireApiKey);

// GET /api/v1/downloader/oembed?url=... — contoh downloader yang legal & tanpa scraping,
// pakai oEmbed resmi (YouTube, Instagram publik, TikTok, dsb menyediakan endpoint oEmbed sendiri).
router.get('/oembed', async (req, res) => {
  const { url } = req.query;
  if (!url) return res.status(400).json({ error: 'url wajib diisi' });

  // Contoh untuk YouTube oEmbed resmi
  try {
    const r = await fetch('https://www.youtube.com/oembed?url=' + encodeURIComponent(url) + '&format=json');
    if (!r.ok) return res.status(404).json({ error: 'Media tidak ditemukan / bukan URL yang didukung' });
    const data = await r.json();
    res.json(data);
  } catch (err) {
    res.status(502).json({ error: 'Gagal mengambil data media' });
  }
});

// Tambahkan platform lain di sini (masing-masing sebaiknya pakai API/oEmbed resmi platform tsb
// atau library resmi mereka, bukan scraping halaman login yang melanggar ToS).

module.exports = router;
