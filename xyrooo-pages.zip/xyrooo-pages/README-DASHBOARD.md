# Xyrooo API Platform — Deploy via Cloudflare Dashboard (tanpa command line)

Ini backend beneran (Cloudflare Pages Functions + D1 Database) yang jalan
real-time dan bisa diakses dari HP manapun. Semua langkah di bawah bisa
dikerjakan dari browser HP kamu, **tidak perlu Termux/laptop/command line**.

## Struktur folder (jangan diubah urutannya saat upload)

```
xyrooo-pages/
├── index.html              ← halaman utama (frontend)
├── schema.sql               ← jalankan isinya lewat Console D1 (langkah 1)
└── functions/                ← backend (Cloudflare Pages Functions)
    ├── _lib/helpers.js
    └── api/
        ├── index.js
        ├── system.js
        ├── auth/
        │   ├── register.js
        │   ├── login.js
        │   ├── google.js
        │   └── google/callback.js
        └── user/
            ├── me.js
            └── regenerate-key.js
```

## Langkah 1 — Buat database D1 (dashboard)

1. Buka https://dash.cloudflare.com → login.
2. Di menu kiri, pilih **Workers & Pages** → tab **D1**.
3. Klik **Create database**. Kasih nama, misal `xyrooo_db`. Klik **Create**.
4. Setelah database dibuat, buka database itu → tab **Console** (kotak query).
5. Buka file `schema.sql` di project ini, **copy semua isinya**, tempel ke
   kotak query itu, lalu klik **Execute**. Kalau muncul "Query executed
   successfully" berarti tabel sudah dibuat.

## Langkah 2 — Buat Google OAuth Client ID & Secret

(Skip langkah ini kalau mau fokus register/login manual dulu, aktifkan
Google belakangan — endpoint lain tetap jalan tanpa ini.)

1. Buka https://console.cloud.google.com/ → buat project baru (nama bebas).
2. Cari menu **OAuth consent screen** → pilih **External** → isi nama app,
   email support, email developer → **Save and Continue** terus sampai selesai.
3. Cari menu **Credentials** → **+ Create Credentials** → **OAuth client ID**.
   - Application type: **Web application**
   - Authorized redirect URIs: isi dulu dengan placeholder, nanti kita
     update lagi setelah tahu domain Pages kamu di Langkah 4:
     `https://xyrooo.pages.dev/api/auth/google/callback`
4. Klik **Create** → copy **Client ID** dan **Client Secret** yang muncul.

## Langkah 3 — Upload project ke Cloudflare Pages

1. Di dashboard Cloudflare, buka **Workers & Pages** → klik **Create**.
2. Pilih tab **Pages** → **Upload assets** (bukan "Connect to Git").
3. Kasih nama project, misal `xyrooo`.
4. Upload/drag seluruh **isi folder** `xyrooo-pages` (index.html, folder
   functions, schema.sql) — bukan file zip-nya, tapi isinya. Kalau
   dashboard hanya menerima folder/drag-drop dari file manager HP, ekstrak
   dulu zip-nya di File Manager HP kamu, baru upload isinya.
5. Klik **Deploy site**. Setelah selesai, Cloudflare kasih kamu URL,
   contoh: `https://xyrooo.pages.dev` — ini domain asli kamu.

## Langkah 4 — Hubungkan database D1 ke project Pages

1. Buka project Pages kamu → tab **Settings** → **Functions**.
2. Scroll ke **D1 database bindings** → **Add binding**.
   - Variable name: `DB` (harus persis huruf besar `DB`, ini dipakai di kode)
   - D1 database: pilih `xyrooo_db` yang tadi dibuat.
3. Klik **Save**.

## Langkah 5 — Isi environment variables & secrets

Masih di **Settings** → **Environment variables** → pilih environment
**Production** → **Add variable**, isi satu-satu:

| Variable name | Value | Tipe |
|---|---|---|
| `JWT_SECRET` | string acak panjang, bebas (contoh: `xkz9Lp2...`, boleh ketik asal-asalan panjang) | **Encrypt** (klik "Encrypt" biar jadi secret) |
| `GOOGLE_CLIENT_ID` | Client ID dari Langkah 2 | Text biasa |
| `GOOGLE_CLIENT_SECRET` | Client Secret dari Langkah 2 | **Encrypt** |
| `GOOGLE_REDIRECT_URI` | `https://xyrooo.pages.dev/api/auth/google/callback` (ganti `xyrooo.pages.dev` dengan domain asli kamu dari Langkah 3) | Text biasa |

Klik **Save**. Setelah menambah/mengubah environment variable, Cloudflare
biasanya minta kamu **re-deploy** (tombol "Retry deployment" di tab
Deployments) supaya perubahan kepakai.

## Langkah 6 — Sinkronkan redirect URI di Google Console

Balik lagi ke Google Cloud Console → Credentials → klik OAuth client kamu
→ update **Authorized redirect URIs** supaya persis sama dengan
`GOOGLE_REDIRECT_URI` di Langkah 5 (domain asli, bukan placeholder). Simpan.

## Selesai — cara tes

1. Buka `https://xyrooo.pages.dev` (domain asli kamu).
2. Coba **Daftar Gratis** dengan email/password — kalau berhasil, artinya
   database dan backend sudah nyambung.
3. Coba **Daftar dengan Google** (kalau Langkah 2 & 6 sudah diisi).

## Kalau masih error 404 / 500 setelah semua langkah ini

- **404** biasanya berarti folder `functions/` tidak ke-upload dengan benar
  (strukturnya harus persis seperti di atas, sejajar dengan `index.html`,
  bukan di dalam subfolder lain).
- **500** biasanya berarti binding `DB` di Langkah 4 belum tersambung, atau
  `JWT_SECRET` belum diisi.
- Cek juga tab **Deployments** → klik deployment terakhir → **Functions**
  logs, di situ biasanya kelihatan pesan error aslinya.
