// Cloudflare Worker — backend untuk xtzy.my.id
// Menangani: GET /  ,  POST /api/auth/register  ,  POST /api/auth/login  ,  GET /api/user/me
//
// Butuh 2 KV namespace (dibind lewat wrangler.toml):
//   USERS    -> key: email       value: JSON { name, salt, hash, apiKey, plan }
//   SESSIONS -> key: token       value: email

const ALLOWED_ORIGIN = 'https://xtzy.my.id';

function corsHeaders(origin) {
  return {
    'Access-Control-Allow-Origin': origin === ALLOWED_ORIGIN ? origin : ALLOWED_ORIGIN,
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Max-Age': '86400',
  };
}

function json(data, status, origin) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...corsHeaders(origin) },
  });
}

function bufToHex(buf) {
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function hashPassword(password, saltHex) {
  const enc = new TextEncoder();
  const salt = saltHex
    ? new Uint8Array(saltHex.match(/.{2}/g).map((h) => parseInt(h, 16)))
    : crypto.getRandomValues(new Uint8Array(16));
  const keyMaterial = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, [
    'deriveBits',
  ]);
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' },
    keyMaterial,
    256
  );
  return { hash: bufToHex(bits), salt: bufToHex(salt) };
}

function randomToken(bytes = 24) {
  return bufToHex(crypto.getRandomValues(new Uint8Array(bytes)).buffer);
}

function randomApiKey() {
  return 'xtzy_' + randomToken(20);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const origin = request.headers.get('Origin') || ALLOWED_ORIGIN;

    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders(origin) });
    }

    // GET / -> ping / cek konektivitas
    if (url.pathname === '/' && request.method === 'GET') {
      return json({ status: 'ok', service: 'xtzy-api' }, 200, origin);
    }

    // POST /api/auth/register
    if (url.pathname === '/api/auth/register' && request.method === 'POST') {
      const body = await request.json().catch(() => ({}));
      const { name, email, password } = body;
      if (!name || !email || !password) {
        return json({ message: 'Nama, email, dan kata sandi wajib diisi.' }, 400, origin);
      }
      const existing = await env.USERS.get(email);
      if (existing) {
        return json({ message: 'Email sudah terdaftar.' }, 409, origin);
      }
      const { hash, salt } = await hashPassword(password);
      const apiKey = randomApiKey();
      const user = { name, salt, hash, apiKey, plan: 'Free' };
      await env.USERS.put(email, JSON.stringify(user));

      const token = randomToken();
      await env.SESSIONS.put(token, email, { expirationTtl: 60 * 60 * 24 * 30 });

      return json({ token, api_key: apiKey }, 201, origin);
    }

    // POST /api/auth/login
    if (url.pathname === '/api/auth/login' && request.method === 'POST') {
      const body = await request.json().catch(() => ({}));
      const { email, password } = body;
      if (!email || !password) {
        return json({ message: 'Email dan kata sandi wajib diisi.' }, 400, origin);
      }
      const raw = await env.USERS.get(email);
      if (!raw) {
        return json({ message: 'Email atau kata sandi salah.' }, 401, origin);
      }
      const user = JSON.parse(raw);
      const { hash } = await hashPassword(password, user.salt);
      if (hash !== user.hash) {
        return json({ message: 'Email atau kata sandi salah.' }, 401, origin);
      }

      const token = randomToken();
      await env.SESSIONS.put(token, email, { expirationTtl: 60 * 60 * 24 * 30 });

      return json({ token, api_key: user.apiKey }, 200, origin);
    }

    // GET /api/user/me  (Authorization: Bearer <token>)
    if (url.pathname === '/api/user/me' && request.method === 'GET') {
      const auth = request.headers.get('Authorization') || '';
      const token = auth.startsWith('Bearer ') ? auth.slice(7) : null;
      if (!token) {
        return json({ message: 'Token tidak ditemukan.' }, 401, origin);
      }
      const email = await env.SESSIONS.get(token);
      if (!email) {
        return json({ message: 'Sesi tidak valid atau kedaluwarsa.' }, 401, origin);
      }
      const raw = await env.USERS.get(email);
      if (!raw) {
        return json({ message: 'Pengguna tidak ditemukan.' }, 404, origin);
      }
      const user = JSON.parse(raw);
      return json({ name: user.name, email, api_key: user.apiKey, plan: user.plan }, 200, origin);
    }

    // GET /api/auth/google?redirect_uri=<halaman-frontend-tujuan>
    // Mengarahkan user ke layar consent Google.
    if (url.pathname === '/api/auth/google' && request.method === 'GET') {
      const redirectUri = url.searchParams.get('redirect_uri') || ALLOWED_ORIGIN;
      // Cegah open-redirect: redirect_uri tujuan akhir wajib ke domain kita sendiri.
      if (!redirectUri.startsWith(ALLOWED_ORIGIN)) {
        return json({ message: 'redirect_uri tidak diizinkan.' }, 400, origin);
      }
      if (!env.GOOGLE_CLIENT_ID) {
        return json({ message: 'Login Google belum dikonfigurasi di server.' }, 500, origin);
      }

      const state = randomToken(16);
      // Simpan tujuan akhir redirect, TTL 10 menit, cukup untuk selesaikan login.
      await env.SESSIONS.put('oauth_state:' + state, redirectUri, { expirationTtl: 600 });

      const callbackUrl = `${ALLOWED_ORIGIN}/api/auth/google/callback`;
      const googleUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
      googleUrl.searchParams.set('client_id', env.GOOGLE_CLIENT_ID);
      googleUrl.searchParams.set('redirect_uri', callbackUrl);
      googleUrl.searchParams.set('response_type', 'code');
      googleUrl.searchParams.set('scope', 'openid email profile');
      googleUrl.searchParams.set('state', state);
      googleUrl.searchParams.set('access_type', 'online');
      googleUrl.searchParams.set('prompt', 'select_account');

      return Response.redirect(googleUrl.toString(), 302);
    }

    // GET /api/auth/google/callback?code=...&state=...
    // Google redirect balik ke sini setelah user setuju login.
    if (url.pathname === '/api/auth/google/callback' && request.method === 'GET') {
      const code = url.searchParams.get('code');
      const state = url.searchParams.get('state');
      if (!code || !state) {
        return json({ message: 'Callback Google tidak lengkap.' }, 400, origin);
      }

      const redirectUri = await env.SESSIONS.get('oauth_state:' + state);
      if (!redirectUri) {
        return json({ message: 'State tidak valid atau kedaluwarsa. Coba login lagi.' }, 400, origin);
      }
      await env.SESSIONS.delete('oauth_state:' + state);

      const callbackUrl = `${ALLOWED_ORIGIN}/api/auth/google/callback`;

      // Tukar authorization code dengan access token
      const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          code,
          client_id: env.GOOGLE_CLIENT_ID,
          client_secret: env.GOOGLE_CLIENT_SECRET,
          redirect_uri: callbackUrl,
          grant_type: 'authorization_code',
        }),
      });
      const tokenData = await tokenRes.json().catch(() => ({}));
      if (!tokenRes.ok || !tokenData.access_token) {
        return json({ message: 'Gagal tukar kode Google: ' + (tokenData.error || 'unknown') }, 400, origin);
      }

      // Ambil profil user dari Google
      const profileRes = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
        headers: { Authorization: 'Bearer ' + tokenData.access_token },
      });
      const profile = await profileRes.json().catch(() => ({}));
      if (!profile.email) {
        return json({ message: 'Gagal ambil profil Google.' }, 400, origin);
      }

      // Buat akun otomatis kalau belum ada (login via Google = tanpa password lokal)
      let raw = await env.USERS.get(profile.email);
      let user;
      if (!raw) {
        user = {
          name: profile.name || profile.email.split('@')[0],
          salt: null,
          hash: null, // akun Google tidak punya password lokal
          apiKey: randomApiKey(),
          plan: 'Free',
          provider: 'google',
        };
        await env.USERS.put(profile.email, JSON.stringify(user));
      } else {
        user = JSON.parse(raw);
      }

      const sessionToken = randomToken();
      await env.SESSIONS.put(sessionToken, profile.email, { expirationTtl: 60 * 60 * 24 * 30 });

      const finalUrl = new URL(redirectUri);
      finalUrl.searchParams.set('token', sessionToken);
      return Response.redirect(finalUrl.toString(), 302);
    }

    return json({ message: 'Not found' }, 404, origin);
  },
};
