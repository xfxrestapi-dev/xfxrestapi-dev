// ============================================
// WORKER.JS - NETFLIX TOKEN API
// CLOUDFLARE WORKER
// ============================================

// ============================================
// 🔑 KONFIGURASI
// ============================================

const CONFIG = {
  // API Keys yang valid
  API_KEYS: [
    'xtzyyyy-8bac15n',
    'xtzyyyy-8bac15n-2',
    'xtzyyyy-8bac15n-3'
  ],
  
  // Kuota per API Key
  QUOTA: {
    'xtzyyyy-8bac15n': 10,
    'xtzyyyy-8bac15n-2': 20,
    'xtzyyyy-8bac15n-3': 30
  },
  
  // Country support
  COUNTRIES: ['US', 'UK', 'CA', 'AU', 'DE', 'FR', 'JP', 'BR', 'IN', 'ID'],
  
  // Creator
  CREATOR: 'xtzy'
};

// ============================================
// 📊 DATABASE SIMULASI (KV)
// ============================================

// Simulasi penyimpanan (di production pakai Cloudflare KV)
const kvStore = {
  tokens: {},
  usage: {}
};

// ============================================
// 🛠️ HELPER FUNCTIONS
// ============================================

function generateToken() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let token = '';
  for (let i = 0; i < 32; i++) {
    token += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return token;
}

function validateAPIKey(key) {
  return CONFIG.API_KEYS.includes(key);
}

function getQuotaRemaining(apiKey) {
  const used = kvStore.usage[apiKey] || 0;
  const total = CONFIG.QUOTA[apiKey] || 0;
  return Math.max(0, total - used);
}

function useQuota(apiKey) {
  if (!kvStore.usage[apiKey]) {
    kvStore.usage[apiKey] = 0;
  }
  kvStore.usage[apiKey]++;
  return kvStore.usage[apiKey];
}

function getExpiryDate() {
  const date = new Date();
  date.setDate(date.getDate() + 30); // 30 hari
  return date.toISOString();
}

function getAccountInfo(country) {
  const plans = {
    'US': { plan: 'Premium', price: '$15.49' },
    'UK': { plan: 'Premium', price: '£10.99' },
    'CA': { plan: 'Premium', price: 'CA$16.99' },
    'AU': { plan: 'Premium', price: 'AU$22.99' },
    'DE': { plan: 'Premium', price: '€12.99' },
    'FR': { plan: 'Premium', price: '€13.49' },
    'JP': { plan: 'Premium', price: '¥1,980' },
    'BR': { plan: 'Premium', price: 'R$55.90' },
    'IN': { plan: 'Mobile', price: '₹199' },
    'ID': { plan: 'Mobile', price: 'Rp 54,000' }
  };

  const plan = plans[country] || { plan: 'Standard', price: 'Unknown' };
  
  return [
    { label: 'Status', value: 'Active · Cancels on ' + new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString() },
    { label: 'Plan', value: plan.plan },
    { label: 'Country', value: country },
    { label: 'Price', value: plan.price }
  ];
}

// ============================================
// 🔥 API HANDLERS
// ============================================

// ----- GENERATE TOKEN -----
async function handleGenerate(request, apiKey, country) {
  const remaining = getQuotaRemaining(apiKey);
  
  if (remaining <= 0) {
    return new Response(JSON.stringify({
      status: false,
      error: 'Quota exhausted',
      remaining: 0
    }), {
      status: 429,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  if (!CONFIG.COUNTRIES.includes(country)) {
    return new Response(JSON.stringify({
      status: false,
      error: 'Country not supported',
      supported: CONFIG.COUNTRIES
    }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  const nftoken = generateToken();
  const expiry = getExpiryDate();
  
  // Simpan token
  const tokenId = `token_${Date.now()}`;
  kvStore.tokens[tokenId] = {
    token: nftoken,
    country: country,
    apiKey: apiKey,
    expires: expiry,
    created: new Date().toISOString()
  };

  // Gunakan kuota
  useQuota(apiKey);
  const newRemaining = getQuotaRemaining(apiKey);

  return new Response(JSON.stringify({
    status: true,
    creator: CONFIG.CREATOR,
    country: country,
    browserLink: `https://www.netflix.com/login?nftoken=${nftoken}`,
    tvLink: `https://www.netflix.com/tv2?nftoken=${nftoken}`,
    mobileLink: `https://netflix.com/unsupported?nftoken=${nftoken}`,
    expires: expiry,
    accountInfo: getAccountInfo(country),
    remaining: newRemaining
  }), {
    status: 200,
    headers: { 'Content-Type': 'application/json' }
  });
}

// ----- CONVERT COOKIES TO TOKEN -----
async function handleConvert(request, apiKey, cookies) {
  const remaining = getQuotaRemaining(apiKey);
  
  if (remaining <= 0) {
    return new Response(JSON.stringify({
      status: false,
      error: 'Quota exhausted',
      remaining: 0
    }), {
      status: 429,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  if (!cookies) {
    return new Response(JSON.stringify({
      status: false,
      error: 'Cookies parameter required'
    }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  const nftoken = generateToken();
  const expiry = getExpiryDate();
  
  // Parse cookies untuk get country
  let country = 'US';
  try {
    const decoded = decodeURIComponent(cookies);
    if (decoded.includes('country=')) {
      const match = decoded.match(/country=([A-Z]{2})/);
      if (match) country = match[1];
    }
  } catch (e) {}

  // Gunakan kuota
  useQuota(apiKey);
  const newRemaining = getQuotaRemaining(apiKey);

  return new Response(JSON.stringify({
    status: true,
    creator: CONFIG.CREATOR,
    browserLink: `https://www.netflix.com/login?nftoken=${nftoken}`,
    mobileLink: `https://netflix.com/unsupported?nftoken=${nftoken}`,
    tvLink: `https://netflix.com/tv2?nftoken=${nftoken}`,
    expires: expiry,
    accountInfo: getAccountInfo(country),
    remaining: newRemaining
  }), {
    status: 200,
    headers: { 'Content-Type': 'application/json' }
  });
}

// ============================================
// 🚀 MAIN HANDLER
// ============================================

async function handleRequest(request) {
  const url = new URL(request.url);
  const path = url.pathname;
  
  // CORS headers
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  };

  // Handle OPTIONS (CORS preflight)
  if (request.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  // ==========================================
  // 📊 API ROUTES
  // ==========================================

  // GET /api/v1/netflix/generate
  if (path === '/api/v1/netflix/generate' || path === '/api/v1/netflix/generate/') {
    const authHeader = request.headers.get('Authorization');
    const apiKey = authHeader?.replace('Bearer ', '');
    
    if (!apiKey || !validateAPIKey(apiKey)) {
      return new Response(JSON.stringify({
        status: false,
        error: 'Invalid API Key'
      }), {
        status: 401,
        headers: { 'Content-Type': 'application/json', ...corsHeaders }
      });
    }

    const country = url.searchParams.get('country') || 'US';
    return handleGenerate(request, apiKey, country);
  }

  // GET /api/v1/netflix/convert
  if (path === '/api/v1/netflix/convert' || path === '/api/v1/netflix/convert/') {
    const authHeader = request.headers.get('Authorization');
    const apiKey = authHeader?.replace('Bearer ', '');
    
    if (!apiKey || !validateAPIKey(apiKey)) {
      return new Response(JSON.stringify({
        status: false,
        error: 'Invalid API Key'
      }), {
        status: 401,
        headers: { 'Content-Type': 'application/json', ...corsHeaders }
      });
    }

    const cookies = url.searchParams.get('cookies');
    return handleConvert(request, apiKey, cookies);
  }

  // GET /api/v1/netflix/status
  if (path === '/api/v1/netflix/status' || path === '/api/v1/netflix/status/') {
    const authHeader = request.headers.get('Authorization');
    const apiKey = authHeader?.replace('Bearer ', '');
    
    if (!apiKey || !validateAPIKey(apiKey)) {
      return new Response(JSON.stringify({
        status: false,
        error: 'Invalid API Key'
      }), {
        status: 401,
        headers: { 'Content-Type': 'application/json', ...corsHeaders }
      });
    }

    const remaining = getQuotaRemaining(apiKey);
    const used = kvStore.usage[apiKey] || 0;
    const total = CONFIG.QUOTA[apiKey] || 0;

    return new Response(JSON.stringify({
      status: true,
      api_key: apiKey,
      quota: {
        total: total,
        used: used,
        remaining: remaining
      },
      creator: CONFIG.CREATOR
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json', ...corsHeaders }
    });
  }

  // GET /api/v1/netflix/keys
  if (path === '/api/v1/netflix/keys' || path === '/api/v1/netflix/keys/') {
    const authHeader = request.headers.get('Authorization');
    const apiKey = authHeader?.replace('Bearer ', '');
    
    // Hanya admin yang bisa akses
    if (!apiKey || apiKey !== 'admin-key') {
      return new Response(JSON.stringify({
        status: false,
        error: 'Admin access required'
      }), {
        status: 403,
        headers: { 'Content-Type': 'application/json', ...corsHeaders }
      });
    }

    const keys = CONFIG.API_KEYS.map(key => ({
      key: key,
      total: CONFIG.QUOTA[key] || 0,
      used: kvStore.usage[key] || 0,
      remaining: getQuotaRemaining(key)
    }));

    return new Response(JSON.stringify({
      status: true,
      keys: keys
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json', ...corsHeaders }
    });
  }

  // ==========================================
  // 🏠 UI Landing Page
  // ==========================================

  // GET / (Landing Page)
  if (path === '/' || path === '/index.html') {
    const html = await getLandingPage();
    return new Response(html, {
      status: 200,
      headers: { 'Content-Type': 'text/html', ...corsHeaders }
    });
  }

  // GET /style.css
  if (path === '/style.css') {
    const css = await getStyles();
    return new Response(css, {
      status: 200,
      headers: { 'Content-Type': 'text/css', ...corsHeaders }
    });
  }

  // GET /script.js
  if (path === '/script.js') {
    const js = await getScript();
    return new Response(js, {
      status: 200,
      headers: { 'Content-Type': 'application/javascript', ...corsHeaders }
    });
  }

  // 404
  return new Response(JSON.stringify({
    status: false,
    error: 'Endpoint not found'
  }), {
    status: 404,
    headers: { 'Content-Type': 'application/json', ...corsHeaders }
  });
}

// ============================================
// 📄 LANDING PAGE HTML
// ============================================

async function getLandingPage() {
  return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Netflix API - xtzy</title>
    <link rel="stylesheet" href="/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
    <div class="particles"></div>
    
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-logo">
                <i class="fas fa-film"></i>
                <span>xtzy<span class="highlight">.dev</span></span>
            </div>
            <div class="nav-links">
                <a href="#features">Features</a>
                <a href="#docs">Docs</a>
                <a href="#pricing">Pricing</a>
                <a href="https://github.com" target="_blank"><i class="fab fa-github"></i></a>
            </div>
            <button class="mobile-menu-btn">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </nav>

    <section class="hero">
        <div class="hero-content">
            <div class="hero-badge">
                <span class="badge-dot"></span>
                <span>v2.0.0 · 99.9% Uptime</span>
            </div>
            <h1 class="hero-title">
                Netflix Token API<br>
                <span class="gradient-text">Premium Access</span>
            </h1>
            <p class="hero-description">
                Generate and convert Netflix tokens instantly with our 
                high-performance REST API. Built for developers, by developers.
            </p>
            <div class="hero-buttons">
                <a href="#docs" class="btn btn-primary">
                    <i class="fas fa-rocket"></i> Get Started
                </a>
                <a href="#docs" class="btn btn-outline">
                    <i class="fas fa-code"></i> Documentation
                </a>
            </div>
            <div class="hero-stats">
                <div class="stat-item">
                    <span class="stat-number">99.9%</span>
                    <span class="stat-label">Uptime</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">10K+</span>
                    <span class="stat-label">Requests/Day</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">30+</span>
                    <span class="stat-label">Countries</span>
                </div>
            </div>
        </div>
        <div class="hero-terminal">
            <div class="terminal-header">
                <div class="terminal-dots">
                    <span class="dot red"></span>
                    <span class="dot yellow"></span>
                    <span class="dot green"></span>
                </div>
                <span class="terminal-title">curl</span>
            </div>
            <div class="terminal-body">
                <div class="command-line">
                    <span class="prompt">$</span>
                    <span class="command">curl -X GET "https://xtzy.dev/api/v1/netflix/generate?country=US" \\</span>
                </div>
                <div class="command-line">
                    <span class="prompt">></span>
                    <span class="command">-H "Authorization: Bearer xtzyyyy-8bac15n"</span>
                </div>
                <div class="command-output">
                    <span class="output-line">{</span>
                    <span class="output-line">  "status": true,</span>
                    <span class="output-line">  "creator": "xtzy",</span>
                    <span class="output-line">  "country": "US",</span>
                    <span class="output-line">  "browserLink": "https://www.netflix.com/login?nftoken=...",</span>
                    <span class="output-line">  "remaining": 10</span>
                    <span class="output-line">}</span>
                </div>
            </div>
        </div>
    </section>

    <section id="features" class="features">
        <div class="section-header">
            <h2>Why <span class="gradient-text">xtzy.dev</span></h2>
            <p>Everything you need to integrate Netflix token generation</p>
        </div>
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon"><i class="fas fa-bolt"></i></div>
                <h3>Lightning Fast</h3>
                <p>Sub-100ms response time with edge computing</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon"><i class="fas fa-shield-alt"></i></div>
                <h3>Enterprise Security</h3>
                <p>Encrypted tokens with API key authentication</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon"><i class="fas fa-globe"></i></div>
                <h3>Global Coverage</h3>
                <p>Support for 30+ countries worldwide</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon"><i class="fas fa-chart-line"></i></div>
                <h3>Quota Management</h3>
                <p>Real-time usage tracking and monitoring</p>
            </div>
        </div>
    </section>

    <section id="docs" class="docs">
        <div class="section-header">
            <h2>API <span class="gradient-text">Documentation</span></h2>
            <p>Simple, powerful, and well-documented endpoints</p>
        </div>
        <div class="docs-container">
            <div class="doc-item">
                <div class="doc-method method-get">GET</div>
                <div class="doc-endpoint">/api/v1/netflix/generate</div>
                <div class="doc-description">Generate a new Netflix token</div>
                <div class="doc-params">
                    <span class="param">?country=US</span>
                    <span class="param">?country=ID</span>
                    <span class="param">?country=IN</span>
                </div>
                <div class="doc-code">
                    <pre>curl -X GET "https://xtzy.dev/api/v1/netflix/generate?country=US" \
  -H "Authorization: Bearer YOUR_API_KEY"</pre>
                </div>
            </div>
            <div class="doc-item">
                <div class="doc-method method-post">POST</div>
                <div class="doc-endpoint">/api/v1/netflix/convert</div>
                <div class="doc-description">Convert cookies to Netflix token</div>
                <div class="doc-params">
                    <span class="param">?cookies=NetflixId%3D...</span>
                </div>
                <div class="doc-code">
                    <pre>curl -X POST "https://xtzy.dev/api/v1/netflix/convert?cookies=NetflixId%3D..." \
  -H "Authorization: Bearer YOUR_API_KEY"</pre>
                </div>
            </div>
            <div class="doc-item">
                <div class="doc-method method-get">GET</div>
                <div class="doc-endpoint">/api/v1/netflix/status</div>
                <div class="doc-description">Check your API key quota status</div>
                <div class="doc-code">
                    <pre>curl -X GET "https://xtzy.dev/api/v1/netflix/status" \
  -H "Authorization: Bearer YOUR_API_KEY"</pre>
                </div>
            </div>
        </div>
    </section>

    <section id="pricing" class="pricing">
        <div class="section-header">
            <h2>Simple, <span class="gradient-text">Transparent</span> Pricing</h2>
            <p>Choose the plan that fits your needs</p>
        </div>
        <div class="pricing-grid">
            <div class="pricing-card">
                <div class="pricing-header">
                    <h3>Starter</h3>
                    <div class="price">$0<span>/mo</span></div>
                    <p>Perfect for testing</p>
                </div>
                <ul class="pricing-features">
                    <li><i class="fas fa-check"></i> 10 requests/day</li>
                    <li><i class="fas fa-check"></i> 3 countries</li>
                    <li><i class="fas fa-check"></i> Basic support</li>
                </ul>
                <a href="#docs" class="btn btn-primary">Get Started</a>
            </div>
            <div class="pricing-card featured">
                <div class="pricing-badge">Popular</div>
                <div class="pricing-header">
                    <h3>Pro</h3>
                    <div class="price">$29<span>/mo</span></div>
                    <p>For serious developers</p>
                </div>
                <ul class="pricing-features">
                    <li><i class="fas fa-check"></i> 10,000 requests/day</li>
                    <li><i class="fas fa-check"></i> 30+ countries</li>
                    <li><i class="fas fa-check"></i> Priority support</li>
                    <li><i class="fas fa-check"></i> Advanced analytics</li>
                </ul>
                <a href="#docs" class="btn btn-primary">Get Started</a>
            </div>
            <div class="pricing-card">
                <div class="pricing-header">
                    <h3>Enterprise</h3>
                    <div class="price">Custom</div>
                    <p>For large scale operations</p>
                </div>
                <ul class="pricing-features">
                    <li><i class="fas fa-check"></i> Unlimited requests</li>
                    <li><i class="fas fa-check"></i> Custom countries</li>
                    <li><i class="fas fa-check"></i> 24/7 dedicated support</li>
                    <li><i class="fas fa-check"></i> SLA guarantee</li>
                </ul>
                <a href="#docs" class="btn btn-outline">Contact Sales</a>
            </div>
        </div>
    </section>

    <footer class="footer">
        <div class="footer-content">
            <div class="footer-brand">
                <i class="fas fa-film"></i>
                <span>xtzy<span class="highlight">.dev</span></span>
                <p>Premium Netflix Token API</p>
            </div>
            <div class="footer-links">
                <a href="#features">Features</a>
                <a href="#docs">Documentation</a>
                <a href="#pricing">Pricing</a>
                <a href="https://github.com" target="_blank">GitHub</a>
            </div>
            <div class="footer-copy">
                <p>&copy; 2026 xtzy.dev. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="/script.js"></script>
</body>
</html>
  `;
}

// ============================================
// 🎨 STYLES
// ============================================

async function getStyles() {
  return `
/* ============================================
   STYLES.CSS - NETFLIX API UI
   ============================================ */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

:root {
    --bg-primary: #0a0a0f;
    --bg-secondary: #12121a;
    --bg-card: #1a1a2e;
    --text-primary: #ffffff;
    --text-secondary: #a0a0b0;
    --accent: #e50914;
    --accent-hover: #ff0a16;
    --gradient: linear-gradient(135deg, #e50914, #ff6b35);
    --border: rgba(255, 255, 255, 0.05);
    --shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
}

html {
    scroll-behavior: smooth;
}

body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    background: var(--bg-primary);
    color: var(--text-primary);
    line-height: 1.6;
    overflow-x: hidden;
    min-height: 100vh;
}

/* ============================================
   PARTICLES
   ============================================ */

.particles {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    z-index: 0;
    background: 
        radial-gradient(ellipse at 20% 50%, rgba(229, 9, 20, 0.05) 0%, transparent 50%),
        radial-gradient(ellipse at 80% 50%, rgba(255, 107, 53, 0.05) 0%, transparent 50%);
}

/* ============================================
   NAVBAR
   ============================================ */

.navbar {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 100;
    background: rgba(10, 10, 15, 0.8);
    backdrop-filter: blur(20px);
    border-bottom: 1px solid var(--border);
    padding: 16px 0;
}

.nav-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.nav-logo {
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 24px;
    font-weight: 800;
    color: var(--text-primary);
}

.nav-logo i {
    color: var(--accent);
}

.nav-logo .highlight {
    color: var(--accent);
}

.nav-links {
    display: flex;
    align-items: center;
    gap: 32px;
}

.nav-links a {
    color: var(--text-secondary);
    text-decoration: none;
    font-size: 14px;
    font-weight: 500;
    transition: color 0.3s ease;
}

.nav-links a:hover {
    color: var(--text-primary);
}

.mobile-menu-btn {
    display: none;
    background: none;
    border: none;
    color: var(--text-primary);
    font-size: 24px;
    cursor: pointer;
}

/* ============================================
   HERO
   ============================================ */

.hero {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 120px 24px 80px;
    position: relative;
    z-index: 1;
    gap: 60px;
    flex-wrap: wrap;
}

.hero-content {
    flex: 1;
    min-width: 300px;
    max-width: 600px;
}

.hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: rgba(229, 9, 20, 0.1);
    border: 1px solid rgba(229, 9, 20, 0.2);
    padding: 8px 16px;
    border-radius: 100px;
    font-size: 13px;
    color: var(--text-secondary);
    margin-bottom: 24px;
}

.badge-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #22c55e;
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.3; }
}

.hero-title {
    font-size: clamp(40px, 8vw, 72px);
    font-weight: 900;
    line-height: 1.1;
    margin-bottom: 24px;
}

.gradient-text {
    background: var(--gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.hero-description {
    font-size: 18px;
    color: var(--text-secondary);
    max-width: 500px;
    margin-bottom: 40px;
    line-height: 1.8;
}

.hero-buttons {
    display: flex;
    gap: 16px;
    flex-wrap: wrap;
    margin-bottom: 48px;
}

/* ============================================
   BUTTONS
   ============================================ */

.btn {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 14px 32px;
    border-radius: 12px;
    font-weight: 600;
    font-size: 16px;
    text-decoration: none;
    transition: all 0.3s ease;
    cursor: pointer;
    border: none;
}

.btn-primary {
    background: var(--gradient);
    color: #fff;
    box-shadow: 0 4px 20px rgba(229, 9, 20, 0.3);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 30px rgba(229, 9, 20, 0.5);
}

.btn-outline {
    background: transparent;
    color: var(--text-primary);
    border: 1px solid rgba(255, 255, 255, 0.1);
}

.btn-outline:hover {
    background: rgba(255, 255, 255, 0.05);
    border-color: rgba(255, 255, 255, 0.2);
}

/* ============================================
   HERO STATS
   ============================================ */

.hero-stats {
    display: flex;
    gap: 40px;
}

.stat-item {
    display: flex;
    flex-direction: column;
}

.stat-number {
    font-size: 28px;
    font-weight: 800;
    color: var(--text-primary);
}

.stat-label {
    font-size: 14px;
    color: var(--text-secondary);
}

/* ============================================
   HERO TERMINAL
   ============================================ */

.hero-terminal {
    flex: 1;
    min-width: 300px;
    max-width: 600px;
    background: var(--bg-secondary);
    border-radius: 16px;
    border: 1px solid var(--border);
    overflow: hidden;
    box-shadow: var(--shadow);
}

.terminal-header {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 16px 20px;
    background: rgba(255, 255, 255, 0.02);
    border-bottom: 1px solid var(--border);
}

.terminal-dots {
    display: flex;
    gap: 8px;
}

.dot {
    width: 12px;
    height: 12px;
    border-radius: 50%;
}

.dot.red { background: #ff5f56; }
.dot.yellow { background: #ffbd2e; }
.dot.green { background: #27c93f; }

.terminal-title {
    font-size: 13px;
    color: var(--text-secondary);
    margin-left: 8px;
}

.terminal-body {
    padding: 20px;
    font-family: 'Courier New', monospace;
    font-size: 14px;
    line-height: 1.8;
}

.command-line {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.prompt {
    color: #22c55e;
}

.command {
    color: var(--text-secondary);
}

.command-output {
    margin-top: 12px;
    padding: 12px 16px;
    background: rgba(0, 0, 0, 0.3);
    border-radius: 8px;
}

.output-line {
    display: block;
    color: #a0a0b0;
}

/* ============================================
   SECTIONS
   ============================================ */

section {
    padding: 80px 24px;
    position: relative;
    z-index: 1;
}

.section-header {
    text-align: center;
    max-width: 600px;
    margin: 0 auto 60px;
}

.section-header h2 {
    font-size: clamp(32px, 5vw, 48px);
    font-weight: 800;
    margin-bottom: 16px;
}

.section-header p {
    font-size: 18px;
    color: var(--text-secondary);
}

/* ============================================
   FEATURES
   ============================================ */

.features-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 24px;
    max-width: 1200px;
    margin: 0 auto;
}

.feature-card {
    background: var(--bg-card);
    padding: 32px 24px;
    border-radius: 16px;
    border: 1px solid var(--border);
    text-align: center;
    transition: all 0.3s ease;
}

.feature-card:hover {
    transform: translateY(-4px);
    border-color: rgba(229, 9, 20, 0.3);
    box-shadow: 0 12px 40px rgba(0, 0, 0, 0.3);
}

.feature-icon {
    width: 60px;
    height: 60px;
    border-radius: 12px;
    background: rgba(229, 9, 20, 0.1);
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 16px;
    font-size: 28px;
    color: var(--accent);
}

.feature-card h3 {
    font-size: 18px;
    margin-bottom: 8px;
}

.feature-card p {
    color: var(--text-secondary);
    font-size: 14px;
    line-height: 1.6;
}

/* ============================================
   DOCS
   ============================================ */

.docs-container {
    max-width: 1200px;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    gap: 24px;
}

.doc-item {
    background: var(--bg-card);
    border-radius: 16px;
    padding: 24px 32px;
    border: 1px solid var(--border);
}

.doc-method {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    margin-bottom: 8px;
}

.method-get {
    background: rgba(34, 197, 94, 0.2);
    color: #22c55e;
}

.method-post {
    background: rgba(59, 130, 246, 0.2);
    color: #3b82f6;
}

.doc-endpoint {
    font-size: 20px;
    font-weight: 600;
    font-family: 'Courier New', monospace;
    color: var(--text-primary);
}

.doc-description {
    color: var(--text-secondary);
    font-size: 14px;
    margin: 4px 0 12px;
}

.doc-params {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    margin-bottom: 12px;
}

.param {
    background: rgba(255, 255, 255, 0.05);
    padding: 4px 12px;
    border-radius: 6px;
    font-size: 13px;
    font-family: 'Courier New', monospace;
    color: var(--text-secondary);
}

.doc-code {
    background: var(--bg-primary);
    border-radius: 8px;
    padding: 12px 16px;
    overflow-x: auto;
}

.doc-code pre {
    font-family: 'Courier New', monospace;
    font-size: 13px;
    color: var(--text-secondary);
    margin: 0;
    white-space: pre-wrap;
    word-break: break-all;
}

/* ============================================
   PRICING
   ============================================ */

.pricing-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 24px;
    max-width: 1200px;
    margin: 0 auto;
}

.pricing-card {
    background: var(--bg-card);
    border-radius: 16px;
    padding: 32px 24px;
    border: 1px solid var(--border);
    text-align: center;
    position: relative;
    transition: all 0.3s ease;
}

.pricing-card:hover {
    transform: translateY(-4px);
}

.pricing-card.featured {
    border-color: var(--accent);
    box-shadow: 0 0 40px rgba(229, 9, 20, 0.1);
}

.pricing-badge {
    position: absolute;
    top: -12px;
    left: 50%;
    transform: translateX(-50%);
    background: var(--gradient);
    padding: 4px 16px;
    border-radius: 100px;
    font-size: 12px;
    font-weight: 600;
}

.pricing-header h3 {
    font-size: 20px;
    margin-bottom: 8px;
}

.pricing-header .price {
    font-size: 40px;
    font-weight: 800;
    margin: 16px 0;
}

.pricing-header .price span {
    font-size: 16px;
    font-weight: 400;
    color: var(--text-secondary);
}

.pricing-header p {
    color: var(--text-secondary);
    font-size: 14px;
}

.pricing-features {
    list-style: none;
    padding: 0;
    margin: 24px 0 32px;
    text-align: left;
}

.pricing-features li {
    padding: 8px 0;
    color: var(--text-secondary);
    font-size: 14px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.pricing-features li i {
    color: var(--accent);
    font-size: 16px;
}

/* ============================================
   FOOTER
   ============================================ */

.footer {
    border-top: 1px solid var(--border);
    padding: 40px 24px;
}

.footer-content {
    max-width: 1200px;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 24px;
    text-align: center;
}

.footer-brand {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
}

.footer-brand i {
    font-size: 24px;
    color: var(--accent);
}

.footer-brand span {
    font-size: 20px;
    font-weight: 800;
}

.footer-brand .highlight {
    color: var(--accent);
}

.footer-brand p {
    color: var(--text-secondary);
    font-size: 14px;
}

.footer-links {
    display: flex;
    gap: 24px;
    flex-wrap: wrap;
}

.footer-links a {
    color: var(--text-secondary);
    text-decoration: none;
    font-size: 14px;
    transition: color 0.3s ease;
}

.footer-links a:hover {
    color: var(--text-primary);
}

.footer-copy p {
    color: var(--text-secondary);
    font-size: 13px;
}

/* ============================================
   RESPONSIVE
   ============================================ */

@media (max-width: 768px) {
    .mobile-menu-btn {
        display: block;
    }

    .nav-links {
        display: none;
        flex-direction: column;
        gap: 16px;
        padding: 16px 0;
    }

    .nav-links.open {
        display: flex;
    }

    .hero {
        padding: 100px 16px 60px;
        gap: 40px;
    }

    .hero-title {
        font-size: 32px;
    }

    .hero-buttons {
        flex-direction: column;
    }

    .hero-stats {
        gap: 24px;
        flex-wrap: wrap;
    }

    .stat-number {
        font-size: 22px;
    }

    .hero-terminal {
        min-width: 0;
        width: 100%;
    }

    .terminal-body {
        font-size: 12px;
        padding: 12px;
    }

    .doc-item {
        padding: 16px;
    }

    .doc-endpoint {
        font-size: 16px;
    }

    .pricing-grid {
        grid-template-columns: 1fr;
    }

    .features-grid {
        grid-template-columns: 1fr;
    }
}
  `;
}

// ============================================
// 📜 SCRIPT
// ============================================

async function getScript() {
  return `
// ============================================
// SCRIPT.JS - NETFLIX API UI
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    // ==========================================
    // 🍔 MOBILE MENU
    // ==========================================

    const menuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');

    if (menuBtn) {
        menuBtn.addEventListener('click', function() {
            navLinks.classList.toggle('open');
        });
    }

    // ==========================================
    // 📍 SMOOTH SCROLL
    // ==========================================

    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // ==========================================
    // 🎯 NAVBAR SCROLL EFFECT
    // ==========================================

    let lastScroll = 0;
    const navbar = document.querySelector('.navbar');

    window.addEventListener('scroll', function() {
        const currentScroll = window.pageYOffset;
        if (currentScroll > lastScroll && currentScroll > 100) {
            navbar.style.transform = 'translateY(-100%)';
        } else {
            navbar.style.transform = 'translateY(0)';
        }
        lastScroll = currentScroll;
    });

    // ==========================================
    // 🔄 INTERACTIVE TERMINAL
    // ==========================================

    const terminalOutput = document.querySelector('.command-output');
    if (terminalOutput) {
        const lines = terminalOutput.querySelectorAll('.output-line');
        lines.forEach((line, index) => {
            line.style.opacity = '0';
            line.style.transform = 'translateY(10px)';
            line.style.transition = \`opacity 0.3s ease \${index * 0.1}s, transform 0.3s ease \${index * 0.1}s\`;
            setTimeout(() => {
                line.style.opacity = '1';
                line.style.transform = 'translateY(0)';
            }, 500 + index * 100);
        });
    }
});
  `;
}

// ============================================
// 🚀 REGISTER WORKER
// ============================================

addEventListener('fetch', event => {
  event.respondWith(handleRequest(event.request));
});