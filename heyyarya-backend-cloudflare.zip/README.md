# HeyyAarya API — Cloudflare Worker

Backend nyata untuk API key + email verification.

## 1. Install
npm install -g wrangler
wrangler login

## 2. Buat D1
wrangler d1 create heyyarya-db

Salin `database_id` ke `wrangler.toml`.

## 3. Buat schema
wrangler d1 execute heyyarya-db --remote --file=schema.sql

## 4. Secrets
wrangler secret put ADMIN_KEY
wrangler secret put EMAIL_API_URL
wrangler secret put EMAIL_API_KEY
wrangler secret put EMAIL_FROM
wrangler secret put PUBLIC_BASE_URL

`EMAIL_API_URL` harus menunjuk ke provider email transaksional yang menerima POST JSON `{to,from,subject,text,html}` dan Authorization Bearer.

## 5. Deploy
wrangler deploy

## 6. Generate API key
POST `/api/v1/apikey/generate` dengan header:
`X-Admin-Key: <ADMIN_KEY>`

Response mengandung API key SATU KALI. Simpan dengan aman.

## 7. Send verification
GET `/api/v1/alight-motion/send?apikey=<API_KEY>&email=user@gmail.com`

Atau POST JSON:
`{"email":"user@gmail.com"}` dengan header `X-API-Key`.

## 8. Verify
GET `/api/v1/alight-motion/verif?email=user@gmail.com&token=<TOKEN>`

Catatan:
- API key disimpan dalam bentuk SHA-256 di D1.
- Token verifikasi disimpan dalam bentuk hash.
- Token berlaku 15 menit dan hanya bisa digunakan sekali.
- Jangan commit secret ke GitHub.
