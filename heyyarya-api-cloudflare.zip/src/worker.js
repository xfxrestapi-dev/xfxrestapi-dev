const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type,X-API-Key",
};

function json(data, status = 200, extra = {}) {
  return new Response(JSON.stringify(data, null, 2), {
    status,
    headers: { "content-type": "application/json; charset=UTF-8", ...CORS, ...extra }
  });
}

function html(body, status = 200) {
  return new Response(body, {
    status,
    headers: { "content-type": "text/html; charset=UTF-8", ...CORS }
  });
}

async function sha256(value) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return [...new Uint8Array(buf)].map(x => x.toString(16).padStart(2, "0")).join("");
}

function randomToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  return [...bytes].map(b => b.toString(16).padStart(2, "0")).join("");
}

function validEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

async function authorize(request, env, url) {
  const key = request.headers.get("X-API-Key") || url.searchParams.get("apikey");
  if (!key) return false;

  // Recommended: store a SHA-256 hash in API_KEY_HASH.
  if (env.API_KEY_HASH) {
    return (await sha256(key)) === env.API_KEY_HASH;
  }

  // Temporary/simple mode for development only.
  return env.API_KEY && key === env.API_KEY;
}

async function sendEmail(env, email, verifyUrl) {
  if (!env.RESEND_API_KEY || !env.MAIL_FROM) {
    return { sent: false, reason: "EMAIL_PROVIDER_NOT_CONFIGURED", verifyUrl };
  }

  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${env.RESEND_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      from: env.MAIL_FROM,
      to: [email],
      subject: "Verify your HeyyAarya API email",
      html: `
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:auto">
          <h2>HeyyAarya API</h2>
          <p>Your email verification request was received.</p>
          <p><a href="${verifyUrl}" style="display:inline-block;padding:12px 18px;background:#111;color:#fff;text-decoration:none;border-radius:10px">Verify Email</a></p>
          <p>This link expires in 15 minutes.</p>
        </div>
      `
    })
  });

  if (!r.ok) {
    return { sent: false, reason: "EMAIL_PROVIDER_ERROR", providerStatus: r.status };
  }

  return { sent: true };
}

async function handleSend(request, env, url) {
  if (!(await authorize(request, env, url))) {
    return json({ status: false, error: "INVALID_API_KEY" }, 401);
  }

  let email = url.searchParams.get("email");
  if (!email && request.method === "POST") {
    try {
      const body = await request.json();
      email = body.email;
    } catch {}
  }

  if (!email || !validEmail(email)) {
    return json({ status: false, error: "INVALID_EMAIL" }, 400);
  }

  email = email.trim().toLowerCase();

  const token = randomToken();
  const tokenHash = await sha256(token);
  const id = crypto.randomUUID();
  const expires = Date.now() + 15 * 60 * 1000;

  await env.DB.prepare(
    `INSERT INTO verification_tokens
     (id,email,token_hash,expires_at,used,created_at)
     VALUES (?1,?2,?3,?4,0,?5)`
  ).bind(id, email, tokenHash, expires, Date.now()).run();

  const verifyUrl = `${url.origin}/api/v1/alight-motion/verif?email=${encodeURIComponent(email)}&token=${encodeURIComponent(token)}`;
  const mail = await sendEmail(env, email, verifyUrl);

  return json({
    status: true,
    message: mail.sent ? "Verification email sent" : "Verification token created; email provider is not configured",
    email,
    expires_in: "15 minutes",
    verification: mail.sent ? { delivered: true } : { delivered: false, verify_url: verifyUrl }
  });
}

async function handleVerify(request, env, url) {
  const email = (url.searchParams.get("email") || "").trim().toLowerCase();
  const token = url.searchParams.get("token") || "";

  if (!email || !validEmail(email)) {
    return json({ status: false, error: "INVALID_EMAIL" }, 400);
  }

  if (!token) {
    return json({
      status: false,
      error: "TOKEN_REQUIRED",
      message: "Use the verification link received by email."
    }, 400);
  }

  const tokenHash = await sha256(token);
  const row = await env.DB.prepare(
    `SELECT id,email,expires_at,used
     FROM verification_tokens
     WHERE email=?1 AND token_hash=?2
     ORDER BY created_at DESC LIMIT 1`
  ).bind(email, tokenHash).first();

  if (!row) return json({ status: false, error: "INVALID_TOKEN" }, 400);
  if (row.used) return json({ status: false, error: "TOKEN_ALREADY_USED" }, 400);
  if (Number(row.expires_at) < Date.now()) return json({ status: false, error: "TOKEN_EXPIRED" }, 400);

  await env.DB.prepare(`UPDATE verification_tokens SET used=1 WHERE id=?1`).bind(row.id).run();
  await env.DB.prepare(
    `INSERT INTO verified_emails (email,verified_at)
     VALUES (?1,?2)
     ON CONFLICT(email) DO UPDATE SET verified_at=excluded.verified_at`
  ).bind(email, Date.now()).run();

  return json({
    status: true,
    message: "Email verified successfully",
    email,
    verified_at: new Date().toISOString()
  });
}

const DASHBOARD = `<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#07070a">
<title>HeyyAarya API</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#07070a;color:#f7f7f8;font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif}
a{color:inherit}.wrap{max-width:1100px;margin:auto;padding:28px 18px 60px}
nav{display:flex;align-items:center;justify-content:space-between;padding:12px 0 32px}
.logo{font-weight:900;letter-spacing:-.04em;font-size:20px}.badge{font-size:12px;padding:7px 10px;border:1px solid #29292f;border-radius:999px;color:#aaa}
.hero{padding:55px 0 35px}.eyebrow{color:#9b9ba5;font-size:13px;text-transform:uppercase;letter-spacing:.18em}.hero h1{font-size:clamp(42px,8vw,82px);line-height:.94;margin:15px 0;letter-spacing:-.07em}.hero p{max-width:700px;color:#a5a5ae;font-size:17px;line-height:1.7}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}.card{background:#0d0d12;border:1px solid #202027;border-radius:18px;padding:22px}.card h3{margin:0 0 8px}.muted{color:#92929b}.ok{color:#73e6a4}.endpoint{margin-top:14px;background:#09090c;border:1px solid #24242b;border-radius:14px;padding:15px;font-family:ui-monospace,monospace;font-size:13px;overflow:auto}
section{margin-top:25px}.title{font-size:25px;letter-spacing:-.03em;margin-bottom:12px}
table{width:100%;border-collapse:collapse;background:#0d0d12;border:1px solid #202027;border-radius:18px;overflow:hidden}td,th{padding:15px;text-align:left;border-bottom:1px solid #202027}th{color:#999;font-size:12px;text-transform:uppercase}
pre{white-space:pre-wrap;background:#09090c;border:1px solid #24242b;padding:18px;border-radius:14px;overflow:auto;color:#ddd}
footer{margin-top:50px;color:#666;font-size:13px}
@media(max-width:750px){.grid{grid-template-columns:1fr}.hero{padding-top:35px}table{font-size:13px}}
</style>
</head>
<body><div class="wrap">
<nav><div class="logo">HeyyAarya<span style="color:#777">.API</span></div><div class="badge">REST API • ONLINE</div></nav>
<div class="hero"><div class="eyebrow">Developer Platform</div><h1>Simple API.<br>Premium UI.</h1><p>REST API platform untuk integrasi aplikasi dengan endpoint email verification yang ringan, aman, dan siap dijalankan di Cloudflare Workers.</p></div>
<div class="grid">
<div class="card"><h3>Cloudflare Edge</h3><p class="muted">Worker berjalan di edge network.</p><strong class="ok">● Online</strong></div>
<div class="card"><h3>Protected API</h3><p class="muted">Endpoint membutuhkan API key.</p><strong class="ok">● Protected</strong></div>
<div class="card"><h3>Email Verify</h3><p class="muted">Token satu kali dengan expiry.</p><strong class="ok">● 15 min</strong></div>
</div>
<section><div class="title">Endpoints</div>
<table><tr><th>Method</th><th>Endpoint</th><th>Auth</th></tr>
<tr><td>GET / POST</td><td>/api/v1/alight-motion/send</td><td>API Key</td></tr>
<tr><td>GET</td><td>/api/v1/alight-motion/verif</td><td>Token</td></tr></table></section>
<section><div class="title">Request</div>
<div class="endpoint">GET https://heyyarya.dev/api/v1/alight-motion/send?apikey=YOUR_API_KEY&amp;email=user@gmail.com</div>
<div class="endpoint">GET https://heyyarya.dev/api/v1/alight-motion/verif?email=user@gmail.com&amp;token=TOKEN</div></section>
<section><div class="title">Example response</div>
<pre>{
  "status": true,
  "message": "Verification email sent",
  "email": "user@gmail.com",
  "expires_in": "15 minutes",
  "verification": {
    "delivered": true
  }
}</pre></section>
<footer>© 2026 HeyyAarya API · Built on Cloudflare Workers + D1</footer>
</div></body></html>`;

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: CORS });
    }

    if (url.pathname === "/" || url.pathname === "/docs") {
      return html(DASHBOARD);
    }

    if (url.pathname === "/api/v1/alight-motion/send" && ["GET","POST"].includes(request.method)) {
      try { return await handleSend(request, env, url); }
      catch (e) { return json({ status:false, error:"INTERNAL_ERROR", message:e.message }, 500); }
    }

    if (url.pathname === "/api/v1/alight-motion/verif" && request.method === "GET") {
      try { return await handleVerify(request, env, url); }
      catch (e) { return json({ status:false, error:"INTERNAL_ERROR", message:e.message }, 500); }
    }

    return json({ status:false, error:"NOT_FOUND" }, 404);
  }
};