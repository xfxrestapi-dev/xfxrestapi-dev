import { json, CORS_HEADERS, getUserFromRequest } from '../../_lib/helpers.js';

export async function onRequestGet({ request, env }) {
  const user = await getUserFromRequest(request, env);
  if (!user) return json({ message: 'Token tidak valid atau kedaluwarsa.' }, 401);
  return json({ name: user.name, email: user.email, api_key: user.api_key, plan: user.plan });
}

export async function onRequestOptions() {
  return new Response(null, { headers: CORS_HEADERS });
}
