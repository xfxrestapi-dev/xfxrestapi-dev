// ============================================
// WORKER.JS - CLOUDFLARE WORKER
// TAMBAHKAN GENERATE API KEY
// ============================================

// ============================================
// 📊 KV DATABASE (Simulasi)
// ============================================

const kvStore = {
  users: {},
  apiKeys: {}
};

// ============================================
// 🛠️ FUNGSI
// ============================================

function generateAPIKey() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let key = '';
  for (let i = 0; i < 32; i++) {
    key += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `xtzy-${key}`;
}

function generateToken() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let token = '';
  for (let i = 0; i < 32; i++) {
    token += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return token;
}

function getQuota() {
  return 10;
}

// ============================================
// 🚀 HANDLER
// ============================================

async function handleRequest(request) {
  const url = new URL(request.url);
  const path = url.pathname;

  // CORS headers
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  };

  if (request.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  // ============================================
  // 📊 REGISTER
  // ============================================
  if (path === '/api/v1/auth/register' && request.method === 'POST') {
    try {
      const body = await request.json();
      const { username, email, password } = body;

      if (!username || !email || !password) {
        return new Response(JSON.stringify({
          status: false,
          error: 'Username, email, dan password wajib diisi'
        }), { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      const userId = `user_${Date.now()}`;
      const apiKey = generateAPIKey();

      // Simpan user
      kvStore.users[email] = {
        id: userId,
        username,
        email,
        password,
        apiKey,
        quota: getQuota(),
        used: 0
      };

      return new Response(JSON.stringify({
        status: true,
        message: 'Registrasi berhasil',
        data: {
          user: { username, email },
          api_key: apiKey,
          quota: getQuota()
        }
      }), { status: 201, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
    } catch (error) {
      return new Response(JSON.stringify({
        status: false,
        error: 'Registrasi gagal'
      }), { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
    }
  }

  // ============================================
  // 🔐 LOGIN
  // ============================================
  if (path === '/api/v1/auth/login' && request.method === 'POST') {
    try {
      const body = await request.json();
      const { email, password } = body;

      const user = kvStore.users[email];
      if (!user || user.password !== password) {
        return new Response(JSON.stringify({
          status: false,
          error: 'Email atau password salah'
        }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
      }

      // Generate token
      const token = generateToken();

      return new Response(JSON.stringify({
        status: true,
        data: {
          user: {
            id: user.id,
            username: user.username,
            email: user.email
          },
          token: token,
          api_key: user.apiKey,
          quota: {
            total: user.quota,
            used: user.used,
            remaining: user.quota - user.used
          }
        }
      }), { status: 200, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
    } catch (error) {
      return new Response(JSON.stringify({
        status: false,
        error: 'Login gagal'
      }), { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
    }
  }

  // ============================================
  // 🔑 GENERATE API KEY
  // ============================================
  if (path === '/api/v1/auth/generate-apikey' && request.method === 'POST') {
    const authHeader = request.headers.get('Authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return new Response(JSON.stringify({
        status: false,
        error: 'Token diperlukan'
      }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
    }

    // Cari user berdasarkan token (simplifikasi)
    let foundUser = null;
    for (const [email, user] of Object.entries(kvStore.users)) {
      if (user.id === 'user_' + token.substring(0, 5)) {
        foundUser = user;
        break;
      }
    }

    if (!foundUser) {
      return new Response(JSON.stringify({
        status: false,
        error: 'User tidak ditemukan'
      }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
    }

    const newApiKey = generateAPIKey();
    foundUser.apiKey = newApiKey;

    return new Response(JSON.stringify({
      status: true,
      message: 'API Key berhasil digenerate',
      api_key: newApiKey
    }), { status: 200, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
  }

  // ============================================
  // 📊 STATUS
  // ============================================
  if (path === '/api/v1/netflix/status' && request.method === 'GET') {
    const authHeader = request.headers.get('Authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return new Response(JSON.stringify({
        status: false,
        error: 'Token diperlukan'
      }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
    }

    let foundUser = null;
    for (const [email, user] of Object.entries(kvStore.users)) {
      if (user.id === 'user_' + token.substring(0, 5)) {
        foundUser = user;
        break;
      }
    }

    if (!foundUser) {
      return new Response(JSON.stringify({
        status: false,
        error: 'User tidak ditemukan'
      }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
    }

    return new Response(JSON.stringify({
      status: true,
      quota: {
        total: foundUser.quota,
        used: foundUser.used,
        remaining: foundUser.quota - foundUser.used
      }
    }), { status: 200, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
  }

  // ============================================
  // 🎬 GENERATE TOKEN
  // ============================================
  if (path === '/api/v1/netflix/generate' && request.method === 'GET') {
    const authHeader = request.headers.get('Authorization');
    const token = authHeader?.replace('Bearer ', '');
    const country = url.searchParams.get('country') || 'US';

    if (!token) {
      return new Response(JSON.stringify({
        status: false,
        error: 'Token diperlukan'
      }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
    }

    let foundUser = null;
    for (const [email, user] of Object.entries(kvStore.users)) {
      if (user.id === 'user_' + token.substring(0, 5)) {
        foundUser = user;
        break;
      }
    }

    if (!foundUser) {
      return new Response(JSON.stringify({
        status: false,
        error: 'User tidak ditemukan'
      }), { status: 401, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
    }

    if (foundUser.used >= foundUser.quota) {
      return new Response(JSON.stringify({
        status: false,
        error: 'Kuota habis',
        remaining: 0
      }), { status: 429, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
    }

    const nftoken = generateToken();
    foundUser.used += 1;
    const remaining = foundUser.quota - foundUser.used;

    return new Response(JSON.stringify({
      status: true,
      creator: 'xtzyyyy',
      country: country,
      browserLink: `https://www.netflix.com/login?nftoken=${nftoken}`,
      tvLink: `https://www.netflix.com/tv2?nftoken=${nftoken}`,
      mobileLink: `https://netflix.com/unsupported?nftoken=${nftoken}`,
      expires: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      accountInfo: [
        { label: 'Status', value: 'Active' },
        { label: 'Plan', value: 'Premium' },
        { label: 'Country', value: country }
      ],
      remaining: remaining
    }), { status: 200, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
  }

  // ============================================
  // 🏠 HOME
  // ============================================
  if (path === '/') {
    return new Response(JSON.stringify({
      status: true,
      message: 'xtzyyyy Netflix Token API',
      version: '2.0.0',
      creator: 'xtzyyyy',
      endpoints: {
        register: '/api/v1/auth/register',
        login: '/api/v1/auth/login',
        generate_apikey: '/api/v1/auth/generate-apikey',
        generate: '/api/v1/netflix/generate?country=US',
        status: '/api/v1/netflix/status'
      }
    }), { status: 200, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
  }

  // 404
  return new Response(JSON.stringify({
    status: false,
    error: 'Endpoint tidak ditemukan'
  }), { status: 404, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
}

addEventListener('fetch', event => {
  event.respondWith(handleRequest(event.request));
});