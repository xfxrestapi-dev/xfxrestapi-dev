import { json, CORS_HEADERS, getUserFromRequest, genApiKey } from '../../_lib/helpers.js';

export async function onRequestPost({ request, env }) {
  const user = await getUserFromRequest(request, env);
  if (!user) return json({ message: 'Token tidak valid atau kedaluwarsa.' }, 401);
  const newKey = genApiKey();
  await env.DB.prepare('UPDATE users SET api_key = ? WHERE id = ?').bind(newKey, user.id).run();
  return json({ api_key: newKey });
}

export async function onRequestOptions() {
  return new Response(null, { headers: CORS_HEADERS });
}
