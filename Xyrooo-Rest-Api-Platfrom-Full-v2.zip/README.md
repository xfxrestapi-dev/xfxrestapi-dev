# Xyrooo Rest Api Platfrom

Landing page + Cloudflare Worker + D1.

## Deploy
1. Upload repository ke GitHub.
2. Cloudflare D1: buat `xyrooo-rest-db`, isi `database_id` pada `worker/wrangler.toml`.
3. Jalankan `npx wrangler d1 execute xyrooo-rest-db --remote --file=schema.sql` dari folder worker.
4. `npm install` lalu `npx wrangler secret put SESSION_SECRET` dan `npx wrangler deploy`.
5. Cloudflare Pages: connect GitHub dan set output directory `pages`.
6. Agar frontend memanggil Worker pada domain yang sama, pasang Worker route untuk `/api/*` pada custom domain tersebut.

## API explorer
Landing page memiliki Execute pada setiap endpoint contoh. API key dapat Generate, Preview/Hide, dan Copy. Execute menampilkan status HTTP dan JSON response.

## Google Login
UI dan route `/api/auth/google` tersedia sebagai titik integrasi OAuth. Set `GOOGLE_CLIENT_ID` dan `GOOGLE_CLIENT_SECRET` sebagai Worker secrets lalu lengkapi callback OAuth sebelum production.

## Endpoint catalog
UI menampilkan kategori Top/New dan contoh endpoint. Jangan mengklaim 380+ provider aktif sebelum upstream API nyata disambungkan pada Worker.
