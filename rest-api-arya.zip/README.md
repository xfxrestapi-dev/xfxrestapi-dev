# AM API — GitHub + Cloudflare Pages + Workers

Arsitektur:
- `pages/` = landing page static untuk Cloudflare Pages
- `worker/` = REST API untuk Cloudflare Workers
- Upstream = `https://am.yappi.my.id`

## Deploy Pages

Cloudflare Dashboard → Workers & Pages → Create application → Pages → Connect to Git.

Set:
- Production branch: `main`
- Build command: `exit 0`
- Build output directory: `pages`

## Deploy Worker

Dari folder `worker`:

```bash
npm install
npx wrangler login
npx wrangler deploy
```

Setelah Worker online, edit `pages/index.html`:

```js
const API_BASE = "https://NAMA-WORKER.workers.dev";
```

Jika memakai custom domain, ganti dengan URL Worker kamu.

## API

```text
GET  /api/status
POST /api/send
POST /api/verify
```

Contoh:

```bash
curl https://NAMA-WORKER.workers.dev/api/status
```

Send:

```bash
curl -X POST https://NAMA-WORKER.workers.dev/api/send \
  -H "Content-Type: application/json" \
  -d '{"email":"user@gmail.com"}'
```

Verify:

```bash
curl -X POST https://NAMA-WORKER.workers.dev/api/verify \
  -H "Content-Type: application/json" \
  -d '{"email":"user@gmail.com","link":"https://example.com/magic-link"}'
```

Gunakan hanya untuk akun dan Magic Link yang memang berwenang kamu akses.
