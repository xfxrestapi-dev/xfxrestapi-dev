import { json, CORS_HEADERS } from '../_lib/helpers.js';

export async function onRequestGet({ request, env }) {
  await env.DB.prepare("UPDATE stats SET value = value + 1 WHERE key = 'total_requests'").run();
  const row = await env.DB.prepare("SELECT value FROM stats WHERE key = 'total_requests'").first();

  return json({
    colo: request.cf ? request.cf.colo : 'DEV',
    country: request.cf ? request.cf.country : '-',
    totalRequests: row ? row.value : 0,
  });
}

export async function onRequestOptions() {
  return new Response(null, { headers: CORS_HEADERS });
}
