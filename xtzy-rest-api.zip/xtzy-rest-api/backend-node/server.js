// Xtzy REST API backend starter — Node.js (Express)
// Struktur ini dibuat supaya gampang di-scale sampai ratusan endpoint:
// setiap kategori (ai, downloader, tools, auth) punya file router sendiri di /routes.

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

const authRoutes = require('./routes/auth');
const aiRoutes = require('./routes/ai');
const downloaderRoutes = require('./routes/downloader');
const toolsRoutes = require('./routes/tools');

const app = express();
app.use(cors());
app.use(express.json({ limit: '5mb' }));

// Rate limit dasar untuk paket free — sesuaikan per-key kalau sudah ada sistem billing
const limiter = rateLimit({
  windowMs: 24 * 60 * 60 * 1000, // 24 jam
  max: 100,
  message: { error: 'Batas request harian tercapai. Upgrade ke Premium untuk limit lebih tinggi.' }
});
app.use('/api/', limiter);

app.get('/health', (req, res) => res.json({ status: 'ok', endpoints: 380 }));

app.use('/api/auth', authRoutes);
app.use('/api/v1/ai', aiRoutes);
app.use('/api/v1/downloader', downloaderRoutes);
app.use('/api/v1/tools', toolsRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint tidak ditemukan', path: req.path });
});

// error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Terjadi kesalahan pada server' });
});

const PORT = process.env.PORT || 8787;
app.listen(PORT, () => console.log(`Xtzy REST API backend jalan di port ${PORT}`));
