import { genApiKey, base64urlToBytes, makeSessionToken } from '../../../_lib/helpers.js';

export async function onRequestGet({ request, env }) {
  const url = new URL(request.url);
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state') || '';
  let returnTo = '/';
  try { returnTo = new TextDecoder().decode(base64urlToBytes(state)); } catch {}
  if (!code) return Response.redirect(returnTo + '?auth_error=missing_code', 302);

  const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code,
      client_id: env.GOOGLE_CLIENT_ID,
      client_secret: env.GOOGLE_CLIENT_SECRET,
      redirect_uri: env.GOOGLE_REDIRECT_URI,
      grant_type: 'authorization_code',
    }),
  });
  const tokenData = await tokenRes.json();
  if (!tokenRes.ok || !tokenData.access_token) {
    return Response.redirect(returnTo + '?auth_error=token_exchange_failed', 302);
  }

  const profileRes = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
    headers: { Authorization: `Bearer ${tokenData.access_token}` },
  });
  const profile = await profileRes.json();
  if (!profileRes.ok || !profile.email) {
    return Response.redirect(returnTo + '?auth_error=profile_fetch_failed', 302);
  }

  let user = await env.DB.prepare('SELECT * FROM users WHERE google_id = ? OR email = ?')
    .bind(profile.id, profile.email).first();

  if (!user) {
    const id = crypto.randomUUID();
    const apiKey = genApiKey();
    const now = Math.floor(Date.now() / 1000);
    await env.DB.prepare(
      'INSERT INTO users (id, name, email, google_id, api_key, plan, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
    ).bind(id, profile.name || profile.email.split('@')[0], profile.email, profile.id, apiKey, 'Free', now).run();
    user = { id };
  } else if (!user.google_id) {
    await env.DB.prepare('UPDATE users SET google_id = ? WHERE id = ?').bind(profile.id, user.id).run();
  }

  const token = await makeSessionToken(user.id, env.JWT_SECRET);
  const redirectUrl = new URL(returnTo);
  redirectUrl.searchParams.set('token', token);
  return Response.redirect(redirectUrl.toString(), 302);
}
