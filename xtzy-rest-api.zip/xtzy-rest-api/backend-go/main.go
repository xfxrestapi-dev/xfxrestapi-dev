// Xtzy REST API backend starter — Go
// Jalankan: go run main.go
package main

import (
	"encoding/json"
	"io"
	"net/http"
	"os"
	"time"

	"github.com/golang-jwt/jwt/v5"
	"google.golang.org/api/idtoken"
)

type GoogleAuthBody struct {
	IDToken string `json:"id_token"`
}

type User struct {
	Email  string `json:"email"`
	Name   string `json:"name"`
	Avatar string `json:"avatar"`
	Plan   string `json:"plan"`
	APIKey string `json:"api_key"`
}

var jwtSecret = []byte(getEnv("JWT_SECRET", "change_me"))
var googleClientID = getEnv("GOOGLE_CLIENT_ID", "")

// Ganti dengan database asli (Postgres/MySQL). Ini contoh in-memory saja.
var users = map[string]User{}

func getEnv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

func writeJSON(w http.ResponseWriter, status int, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(data)
}

func healthHandler(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, 200, map[string]interface{}{"status": "ok", "endpoints": 380})
}

func googleAuthHandler(w http.ResponseWriter, r *http.Request) {
	body, _ := io.ReadAll(r.Body)
	var payload GoogleAuthBody
	json.Unmarshal(body, &payload)

	if payload.IDToken == "" {
		writeJSON(w, 400, map[string]string{"message": "id_token wajib diisi"})
		return
	}

	tokenPayload, err := idtoken.Validate(r.Context(), payload.IDToken, googleClientID)
	if err != nil {
		writeJSON(w, 401, map[string]string{"message": "id_token tidak valid"})
		return
	}

	email := tokenPayload.Claims["email"].(string)
	name, _ := tokenPayload.Claims["name"].(string)
	picture, _ := tokenPayload.Claims["picture"].(string)

	user, exists := users[email]
	if !exists {
		user = User{Email: email, Name: name, Avatar: picture, Plan: "free", APIKey: "xtzy_live_" + email}
		users[email] = user
	}

	claims := jwt.MapClaims{
		"sub":  email,
		"name": name,
		"exp":  time.Now().Add(7 * 24 * time.Hour).Unix(),
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	signed, _ := token.SignedString(jwtSecret)

	writeJSON(w, 200, map[string]interface{}{"session_token": signed, "user": user})
}

func requireAPIKey(r *http.Request) bool {
	return r.Header.Get("x-api-key") != ""
}

func movieHandler(w http.ResponseWriter, r *http.Request) {
	if !requireAPIKey(r) {
		writeJSON(w, 401, map[string]string{"error": "Header x-api-key wajib diisi"})
		return
	}
	title := r.URL.Query().Get("title")
	if title == "" {
		writeJSON(w, 400, map[string]string{"error": "title wajib diisi"})
		return
	}
	apiKey := getEnv("OMDB_API_KEY", "")
	resp, err := http.Get("https://www.omdbapi.com/?apikey=" + apiKey + "&t=" + title)
	if err != nil {
		writeJSON(w, 502, map[string]string{"error": "Gagal mengambil data film"})
		return
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	w.Header().Set("Content-Type", "application/json")
	w.Write(body)
}

func main() {
	mux := http.NewServeMux()
	mux.HandleFunc("/health", healthHandler)
	mux.HandleFunc("/api/auth/google", googleAuthHandler)
	mux.HandleFunc("/api/v1/tools/movie", movieHandler)

	// Tambahkan endpoint lain di sini dengan pola yang sama:
	// cek requireAPIKey(r), lalu proxy ke provider resmi terkait.

	port := getEnv("PORT", "8787")
	http.ListenAndServe(":"+port, mux)
}
